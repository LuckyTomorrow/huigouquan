<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends Controller {

	///
	///首页展示
	///

    public function index(){
        if(C('end_flag')==1){
            return;die;
        }

        ini_set('max_execution_time', '0');
		$Goods = new \Common\Common\ApiData();
        $modelDatas = M('api'); //分类商品
        $modelToday = M('today'); //今日商品
        $modelTotal = M('total'); //总商品
        $modelTop100= M("top100"); //TOP100
        $modelPingpai= M('pingpai'); //品牌商品
        $modelJingpai= M('jingpai'); //金牌卖家
        $modelHaiwai= M('haiwai'); //海外精选
        $modelJuhs= M('juhs'); //海外精选
        $modelTaoqg= M('taoqg'); //海外精选

        $interval=5*60*60;//每隔一定时间运行
        $url02="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
        $pid="mm_113516953_36040316_132152895";

            if($modelDatas->count()){
                $modelDatas->where("1")->delete();  
            }
            if($modelToday->count()){
                $modelToday->where("1")->delete();
            }
            if($modelTotal->count()){
                $modelTotal->where("1")->delete();
            }
            if($modelTop100->count()){
                $modelTop100->where("1")->delete();
            }
            if($modelPingpai->count()){
                $modelPingpai->where("1")->delete();
            }
            if($modelJingpai->count()){
                $modelJingpai->where("1")->delete();
            }
            if($modelHaiwai->count()){
                $modelHaiwai->where("1")->delete();
            }
            if($modelJuhs->count()){
                $modelJuhs->where("1")->delete();
            }
            if($modelTaoqg->count()){
                $modelTaoqg->where("1")->delete();
            }

            $arrs= NULL;
            
            //获取分类商品的json数据
            for($i=1;$i<=14;$i++){
                if($i==6){
                    continue;
                } 

                for($j=1;$j<=50;$j++){

                    $url = "http://api.yishoudan.com/index/index?pname=page&aname=page&cid=".$i."&p=".$j."&json=1";
                    $arrs = $Goods -> getDatas($url);
                    if(empty($arrs)){
                        break;
                    }
                    
                    $this->addPid($arrs,$pid);
                    $modelDatas->addAll($arrs);
                }               
                
            }

            //获取总商品的json数据
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelTotal->addAll($arrs);
            } 

            //获取今天商品的json数据
            date_default_timezone_set('PRC');
            $add_time = mktime(0, 0, 0, date("m"), date("d"), date("Y"));
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&add_time=".$add_time."&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelToday->addAll($arrs);
            } 

            //获取销量TOP100的json数据
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&volume=desc&shop_type=B&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelTop100->addAll($arrs);
            } 
            

            //获取品牌推荐的json数据            
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&star_pp=1&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelPingpai->addAll($arrs);
            } 

            //获取金牌卖家的json数据
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&isau=1&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelJingpai->addAll($arrs);
            }

            //获取海外商品的json数据
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&ishaiwai=1&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelHaiwai->addAll($arrs);
            }

            //获取聚划算商品的json数据
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&isjhs=1&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelJuhs->addAll($arrs);
            }

            //获取淘抢购商品的json数据
            for($i=1;$i<=50;$i++){

                $url = "http://api.yishoudan.com/index/index?&pname=page&aname=page&p=".$i."&istqg=1&json=1";
                $arrs = $Goods -> getDatas($url);
                if(empty($arrs)){
                    break;
                }
                    
                $this->addPid($arrs,$pid);
                $modelTaoqg->addAll($arrs);
            }

        sleep($interval);
        file_get_contents($url02);
        
   	}	

    public function addPid(&$datas,$pid){
        if(empty($datas)){
            return;
        }

        for ($i=0;$i<count($datas);$i++) {
            $datas[$i]['cid'] = intval($datas[$i]['cid']);
            $datas[$i]['diadurl'].= $pid;
        }

        $this->checkData($datas);
    }

    public function checkData(&$datas){
        if(empty($datas)){
            return;
        }

        for ($i=0;$i<count($datas);$i++) {
            if( $datas[$i]['cid'] >=15){
                unset($datas[$i]);
            }
        }
    }
    
}