<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2009 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id: Page.class.php 2712 2012-02-06 10:12:49Z liu21st $
namespace Home\Common;
class AjaxPage {
    // 分页栏每页显示的页数
    public $rollPage = 5;
    
    // 默认列表每页显示行数
    public $listRows = 20;
    // 起始行数
    public $firstRow ;
    // 分页总页面数
    public $totalPages  ;
    // 总行数
    public $totalRows  ;
    //商品分类号(个人定制功能)
    public $cat_id ;
    // 当前页数
    public $nowPage    ;
    // 分页栏的总数
    public $coolPages   ;
    // 分页显示定制
    protected $config  = array('prev'=>'上一页','next'=>'下一页','theme'=>' %prePage% %nextPage%');
    // 默认分页变量名称
    public $varPage;

    //初始化时，计算出当前页数和起始行数
    public function __construct($totalRows,$listRows=20,$cat_id=0,$ajax_func='server') {
        $this->totalRows = $totalRows;  //总记录数
        $this->ajax_func = $ajax_func;  //对应js的ajax功能函数名
        
        //page参数名字获取，如果config文件有定义则取config，没有，则默认为“page” 
        $this->varPage = C('VAR_PAGE') ? C('VAR_PAGE') : 'page' ;
        $this->listRows = intval($listRows);

        //计算总页数，向上取整
        $this->totalPages = ceil($this->totalRows/$this->listRows);     
        //计算分栏数，用于比如每隔5页向前向后跳转
        $this->coolPages  = ceil($this->totalPages/$this->rollPage);

        //如果url中没有var_page参数，则默认为第一页处理
        $this->nowPage  = !empty($_GET[$this->varPage])?intval($_GET[$this->varPage]):1;

        //商品cat_id类
        $this->cat_id  = $cat_id;

        //防呆处理:如果当前页大于总页数，则将总页数值赋值给当前页（常发生于在当前页为最后一页时按“下一页”操作）
        if(!empty($this->totalPages) && ($this->nowPage > $this->totalPages) ){
            $this->nowPage = $this->totalPages;
        }

        //当前页的起始行数，本应该是要加1才是当前页的第一行
        //但考虑该属性是用于limit(n,m)方法的第一个参数，也即跳过n行取m行的意思
        //故这里的实际效果是当前页的上一页尾行的行号
        $this->firstRow = $this->listRows*($this->nowPage-1)+1;
    }

    //修改config参数
    public function setConfig($name,$value) {
        if(isset($this->config[$name])) {
            $this->config[$name]    =   $value;
        }
    }

    //根据当前页，计算得到分页相关格式和数据字符串
    public function show() {
        //如果没有数据，返回空
        if(0 == $this->totalRows) return '';
        $upRow = $this->nowPage - 1;
        $downRow = $this->nowPage + 1;

        if ($upRow>0){
            $upPage="<div class='category_page' id='cat_ajax'><a id='last_page' href='JavaScript:".$this->ajax_func."(".$this->cat_id.",".$upRow.")'>".$this->config['prev']."</a>";
        }else{
            $upRow=1;
            $upPage="<div class='category_page' id='cat_ajax'><a id='last_page' href='JavaScript:".$this->ajax_func."(".$this->cat_id.",".$upRow.")'>".$this->config['prev']."</a>";
        }

        if ($downRow <= $this->totalPages){
            $downPage="<a id='next_page'   href='JavaScript:".$this->ajax_func."(".$this->cat_id.",".$downRow .")'>".$this->config['next']."</a></div>";
        }else{
            $downRow = $this->totalPages;
            $downPage="<a id='next_page'   href='JavaScript:".$this->ajax_func."(".$this->cat_id.",".$downRow .")'>".$this->config['next']."</a></div>";
        }
        
        $pageStr  =  str_replace(  
            array('%prePage%','%nextPage%'),
            array($upPage,$downPage),
            $this->config['theme']
        ); 

        return $pageStr;
    }

}

?>