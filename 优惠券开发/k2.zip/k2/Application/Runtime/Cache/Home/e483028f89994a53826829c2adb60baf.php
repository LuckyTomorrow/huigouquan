<?php if (!defined('THINK_PATH')) exit();?>
<div id= "ajaxPart">
			<!--<div class="promise"></div>-->
			<div class="cat-wrap wrap">
					<div class="cat-list clearfix">
						<span class="cat-lit-title">商品分类</span>
						<ul class="clearfix">
							<li class="active">
								<a class="ajax_cid" id="ajax_cat_0" href="javascript:getticket(0,1,0);">全部优惠</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_1" href="javascript:getticket(0,1,1);">女装</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_2" href="javascript:getticket(0,1,2);">男装</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_3" href="javascript:getticket(0,1,3);">内衣</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_4" href="javascript:getticket(0,1,4);">母婴</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_5" href="javascript:getticket(0,1,5);">包包</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_7" href="javascript:getticket(0,1,7);">居家</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_8" href="javascript:getticket(0,1,8);">鞋品</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_9" href="javascript:getticket(0,1,9);">美食</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_10" href="javascript:getticket(0,1,10);">文体</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_11" href="javascript:getticket(0,1,11);">家电</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_13" href="javascript:getticket(0,1,13);">配饰</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_14" href="javascript:getticket(0,1,14);">数码</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_12" href="javascript:getticket(0,1,12);">其他</a>
							</li>											
						</ul>
						
                    </div>
					<div class="cat-list sale-type clearfix">
						<span class="cat-lit-title">价格分类</span>
						<ul class="clearfix">
							<li><a class="ajax_ticket" id="ajax_ticket_1" href="javascript:getticket(1,1,<?php echo ($cid); ?>);">大于100元券</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_2" href="javascript:getticket(2,1,<?php echo ($cid); ?>);">50-100元券</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_3" href="javascript:getticket(3,1,<?php echo ($cid); ?>);">30-50元券</a></li> 
							<li><a class="ajax_ticket" id="ajax_ticket_4" href="javascript:getticket(4,1,<?php echo ($cid); ?>);">10-30元券</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_5" href="javascript:getticket(5,1,<?php echo ($cid); ?>);">10元以下券</a></li>
						</ul>
					</div>
			</div>
	
			<div class="goods-list wrap">
				<ul class="clearfix">

				<?php if(is_array($datas)): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?><li class="g_over">
						<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?> class="img" target="_blank">
							<?php if(($data['shop_type']) == 'B'): ?><i class="index_tmall"></i>
							<?php else: ?><i class="index_taobao"></i><?php endif; ?>
							<img alt=<?php echo ($data['oldtitle']); ?> class="wsgw-lazy" src=<?php echo ($data['pic_url']); ?>  data-original=<?php echo ($data['pic_url']); ?>>
						</a>
						<div class="goods-padding">
							<div class="coupon-wrap clearfix">
								<span class="price"><b><i>￥</i><?php echo ($data['coupon_quan_price']); ?></b> 券后价</span>
								<span class="old-price"><i>￥</i><?php echo ($data['coupon_price']); ?></span>
								<span class="coupon"><em class="quan-left"></em>券<b><i>￥</i><?php echo ($data['quan']); ?></b><em class="quan-right"></em></span>
							</div>
							<div class="title">
								<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?>>
									<?php echo ($data['title']); ?>
								</a>
							</div>
							<div class="product-box">
		                        <div class="produt_fl">
			                        <div class="goods-num-type">
			                        	<span class="goods-num">销量<b><?php echo ($data['volume']); ?></b></span>
			                        </div>
			                        <div class="sale-title clearfix">
			                            <span class="product-label">
			                            	<span class="con">有效时间</span><i class="i-right"></i>
			                            </span>
			                            <span class="sale-title-font pline"><?php echo (date("m.d",$data['coupon_start_time'])); ?>-<?php echo (date("m.d",$data['coupon_end_time'])); ?></span>
			                        </div>
			                    </div>
			                    <div class="produt_fr">
			                        <a href=<?php echo ($data['diadurl']); ?> target="_blank" title=<?php echo ($data['title']); ?>>领券购买</a>
			                    </div>
		                    </div>
						</div>   
					</li><?php endforeach; endif; else: echo "" ;endif; ?>
									
		 	</div>
		
				<?php echo ($page); ?>
</div>