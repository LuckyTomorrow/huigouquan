<?php if (!defined('THINK_PATH')) exit();?><html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script src="//alimama.alicdn.com/tkapi/plugin/aroundbox.js?_t=20130226.js" async="" charset="utf-8" mod_name="tkapi-plugin-aroundbox"></script>
	<script src="//alimama.alicdn.com/tkapi/plugin/keyword.js?_t=20130226.js" async="" charset="utf-8" mod_name="tkapi-plugin-keyword"></script>
	<script src="https://hm.baidu.com/hm.js?d742034f17d764760810e1dd5e89a698"></script>
	<script src="//alimama.alicdn.com/tkapi/plugin.js?_t=20130226.js" async="" charset="utf-8" mod_name="tkapi-plugin"></script>
	<script src="//alimama.alicdn.com/tkapi/click.js?_t=20130226.js" async="" charset="utf-8" mod_name="tkapi-click"></script>
	<script charset="gbk" async="" src="http://a.alimama.cn/tkapi.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>惠购券,天猫优惠券,精选天猫商品,优惠精选</title>
	<meta name="Keywords" content="惠购券，天猫优惠券，精选天猫商品，优惠精选">
	<meta name="Description" content="惠购券,天猫优惠券,精选天猫商品,优惠精选"> 
	<link href="/k2/Public/css/global.css" rel="stylesheet" type="text/css">
	<link href="/k2/Public/css/index.css" rel="stylesheet" type="text/css">
	<link href="/k2/Public/css/newcommontwo.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="/k2/Public/js/jquery.js"></script> 
	<script type="text/javascript" src="/k2/Public/js/global.js"></script>
	<script type="text/javascript" src="/k2/Public/js/go-top.js"></script>
	<script type="text/javascript" src="/k2/Public/js/globalv.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.SuperSlide.js"></script>
	<script type="text/javascript" src="/k2/Public/js/index.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.lazyload.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jq.cookie.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jq.popup.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.dlzc.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/masonry.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.infinitescroll.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.SuperSlide.2.1.1.js"></script>
	<!--
	<script src="http://l.tbcdn.cn/apps/top/x/sdk.js?appkey=21781928"></script>
	-->
	<style type="text/css">
		.list ul{float:left;}
		.ctips{text-align:center;}
		.ico1,.ico2{display:block;float:left;width:10px;}
		.ico1{background:url("/static/images/Sort.gif") no-repeat scroll left 16px rgba(0, 0, 0, 0);}
		.ico2{background:url("/static/images/Sort.gif") no-repeat scroll -10px 16px rgba(0, 0, 0, 0);}
		.Sort ul li{float:right;}
	</style>
	
	<script type="text/javascript">
	    (function(win,doc){
	        var s = doc.createElement("script"), h = doc.getElementsByTagName("head")[0];
	        if (!win.alimamatk_show) {
	            s.charset = "gbk";
	            s.async = true;
	            s.src = "http://a.alimama.cn/tkapi.js";
	            h.insertBefore(s, h.firstChild);
	        };
	        var o = {
	        	pid=  mm_113516953_36040316_128360575
	            pid: "mm_113516953_36040316_128360575",/*推广单元ID，用于区分不同的推广渠道*/
	            appkey: "",/*通过TOP平台申请的appkey，设置后引导成交会关联appkey*/
	            unid: "",/*自定义统计字段*/
	            type: "click" /* click 组件的入口标志 （使用click组件必设）*/
	        };
	        win.alimamatk_onload = win.alimamatk_onload || [];
	        win.alimamatk_onload.push(o);
	    })(window,document);
	</script>
	<script type="text/javascript">
		$(function(){
			$(window).scroll(function() {
				if($(window).scrollTop() >= 1700){ //向下滚动像素大于这个值时，即出现浮窗~
					$('.index_floatage').fadeIn(300); //浮窗淡入的时间，越小出现的越快~
				} else {
					$('.index_floatage').fadeOut(300); //浮窗淡出的时间，越小消失的越快~
				}
			});
		});
	</script>
</head>

<body>
	<div class="headerBar" _hover-ignore="1">
		<div class="wrap">
			<style>
				.fr {
				    float: right;
				}
				.fl {
				    float: left;
				}

				.headerBar{height:35px;line-height:35px;font-size:12px;background:#F2F2F2;}
				.headerBarNav{}
				.headerBarNav li{float:left;}
				.headerBarNav a{display:block;padding:0 10px;}
				.headerBarNav a:hover .icon_1{background-position:0 -16px;}
				.headerBarNav a:hover .icon_2{background-position:-16px -16px;}
				.headerBarNav a:hover .icon_3{background-position:-32px -16px;}
				.headerBarNav i{float:left;width:16px;height:16px;margin:9px 2px 0 0;}
				.headerBarNav .h:link,.headerBarNav .h:visited{color:#EC425B;}
				.header_fl{color:#333;float:left;}
				.header_fr{float:right;}
				.header_fl a{color:#ed145b}
				.header_fl a:hover{text-decoration:underline;}

			</style>
			
	    </div>
	</div>

	<div class="header">
		<div class="wrap">
			<h1><a style="width:390px;" href="http://www.5395.com/" class="logo" title="5395网上购物" _hover-ignore="1">5395网上购物</a></h1>
			<div class="headerR"><img src="/static/5395_150306/images/headerR.png"></div>
			<div class="index_search">
				<form class="searchBox" action="<?php echo U('Cid/search');?>" method="post">
					<input name="keywords" class="searchBoxInput" placeholder="请输入要查找优惠卷的商品名称…" style="color: rgb(156, 154, 156);" type="text">
					<input name="" class="searchBoxButton" value="搜索" type="submit">					
				</form>
				<div class="index_kjgjc">
					<a href="http://www.5395.com/item/quan.php?keywords=连衣裙" target="blank">连衣裙</a>
					<a href="http://www.5395.com/item/quan.php?keywords=男鞋" target="blank">男鞋</a>
					<a href="http://www.5395.com/item/quan.php?keywords=女鞋" target="blank"> 女鞋</a>
					<a href="http://www.5395.com/item/quan.php?keywords=中老年女装" target="blank">中老年女装</a>
					<a href="http://www.5395.com/item/quan.php?keywords=T恤" target="blank">T恤</a>
					<a href="http://www.5395.com/item/quan.php?keywords=雪纺衫" target="blank">雪纺衫</a>
					<a href="http://www.5395.com/item/quan.php?keywords=孕妇装" target="blank">孕妇装</a>
					<a href="http://www.5395.com/item/quan.php?keywords=女包" target="blank">女包</a>
					<a href="http://www.5395.com/item/quan.php?keywords=运动套装" target="blank">运动套装</a>
					<a href="http://www.5395.com/item/quan.php?keywords=牛仔裤" target="blank">牛仔裤</a>
				</div>
			</div>	
		</div>
	</div>
	<div class="nav">
		<div class="wrap">
			<ul>
				<?php if(is_array($flags)): $i = 0; $__LIST__ = $flags;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li
					<?php if($vo['controllername'] == $name): ?>class="on"<?php endif; ?> 

				><a href=<?php echo ($vo['url']); ?>  target="blank">
						<?php echo ($vo['name']); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>

	<div class="index_contain wrap">
		<div class="index_navmenu">
				<a href="<?php echo U('Cid/index','cat_id=1');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/女装.png" alt="女装" title="女装">
						女装
					</div>
				</a>
		        <a href="<?php echo U('Cid/index','cat_id=2');?>" class="cate_item">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/男装.png" alt="男装" title="男装">
						男装
					</div>
				</a>
				<a href="<?php echo U('Cid/index','cat_id=8');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/鞋子.png" alt="鞋子" title="鞋子">
						鞋子
					</div>
				</a>
		        <a href="<?php echo U('Cid/index','cat_id=5');?>" class="cate_item">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/箱包.png" alt="箱包" title="箱包">
						包包
					</div>
				</a>
				<a href="<?php echo U('Cid/index','cat_id=11');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/家电.png" alt="家电" title="家电">
						家电
					</div>
				</a>
		        <a href="<?php echo U('Cid/index','cat_id=7');?>" class="cate_item">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/居家.png" alt="居家" title="居家">
						居家
					</div>
				</a>
				<a href="<?php echo U('Cid/index','cat_id=9');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/美食.png" alt="美食" title="美食">
						美食
					</div>
				</a>
		        <a href="<?php echo U('Cid/index','cat_id=3');?>" class="cate_item">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/内衣.png" alt="内衣" title="内衣">
						内衣
					</div>
				</a>
				<a href="<?php echo U('Cid/index','cat_id=10');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/运动.png" alt="文体" title="文体">
						文体
					</div>
				</a>
		        <a href="<?php echo U('Cid/index','cat_id=14');?>" class="cate_item">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/数码.png" alt="数码" title="数码">
						数码
					</div>
				</a>
				<a href="<?php echo U('Cid/index','cat_id=4');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/母婴.png" alt="母婴" title="母婴">
						母婴
					</div>
				</a>
		        <a href="<?php echo U('Cid/index','cat_id=13');?>" class="cate_item">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/配饰.png" alt="配饰" title="配饰">
						配饰
					</div>
				</a>
				<a href="<?php echo U('Cid/index','cat_id=12');?>" class="cate_item with_line">
					<div class="inner"><img style="height: 21px;width: 21px;vertical-align:middle;margin-right: 5px " src="/k2/Public/icon/其他.png" alt="其他" title="其他">
						其他
					</div>
				</a>
		        
    	</div>
	<div id="slideBox" class="slideBox">
				<div class="hd">
					<ul>
						<li class="on"></li>
						<li class=""></li>
                        <li class=""></li>
                        <li class=""></li>
                        <li class=""></li>
					</ul>
				</div>
				<div class="bd">
					<ul>
                    	<li style="display: list-item;">
                    		<a href="http://www.lianyunshop.com" target="_blank">
                    			<img src="themes/5395_l/images/index_slide_9.jpg" alt="淘宝优惠券" title="淘宝优惠券">
                    		</a>
                    	</li>
						<li style="display: none;">
							<a href="http://www.5395.com/item/quan.php?keywords=%E5%A6%88%E5%A6%88%E8%A3%85" target="_blank">
								<img src="themes/5395_l/images/index_slide_8.jpg" alt="淘宝优惠券" title="淘宝优惠券">
							</a>
						</li>
                        <li style="display: none;">
                        	<a href="http://www.5395.com/item/quan.php?t=3" target="_blank">
                        		<img src="themes/5395_l/images/index_slide_7.jpg" alt="淘宝优惠券" title="淘宝优惠券">
                        	</a>
                        </li>
                        <li style="display: none;">
                        	<a href="javascript:;">
                        		<img src="themes/5395_l/images/slide_3_m.jpg" alt="淘宝优惠券" title="淘宝优惠券" _hover-ignore="1">
                        	</a>
                        </li>
						<li style="display: none;">
							<a href="https://s.click.taobao.com/t?e=m%3D2%26s%3D%2BdRxEKEMK2kcQipKwQzePCperVdZeJviEViQ0P1Vf2kguMN8XjClAlMS%2BHDc69Xf%2FuaHtoit7JFnaw97AzP0cQDrndQ6GOy6%2B%2FAPSGN%2F8OahpPGVBthZ3Oo0BcZWWIRYYA%2FDpPH01wJAFEHVckI7b7Sgd9R%2Fv5WktY4Qt2cZ1lVeY%2By0blbhscYl7w3%2FA2kb" target="_blank">
								<img src="themes/5395_l/images/index_slide_2.jpg" alt="淘宝优惠券" title="淘宝优惠券" _hover-ignore="1">
							</a>
						</li>
					</ul>
				</div>
	</div>
	<div class="index_conpons">
		<a target="blank" href="http://shang.qq.com/wpa/qunwpa?idkey=">
			<img src="themes/5395_l/images/mrbp.jpg" alt="内部优惠券分享群9" title="内部优惠券分享群9">
		</a>
		<a target="blank" href="/item/quan.php?qp=4">
			<img src="themes/5395_l/images/hotbottom.jpg" alt="淘宝优惠券" title="淘宝优惠券">
		</a>
	</div>
</div>
	
		<div class="index_jxtm wrap">
        	<div class="jxtm_title">精选特卖</div>
        	<div class="jxtm_bottom">
        		<ul>
        			<li><a href="/item/quan.php?cate_id=119" target="_blank"><img src="/static/images/banner/1.jpg"></a></li>
        			<li><a href="/item/quan.php?cate_id=101" target="_blank"><img src="/static/images/banner/2.jpg"></a></li>
        			<li><a href="/item/quan.php?cate_id=107" target="_blank"><img src="/static/images/banner/3.jpg"></a></li>
        		</ul>
        	</div>
        </div>


		<div id="body_top_ajax"></div>

	<div id="ajax_total">			
		<div class="index_category wrap">
        	<div class="category_top">
        		<div class="category_menu">
        			<ul>
        				<li><a class="ajax_top" id="ajax_cat_30" href="javascript:server(30,1);">今日爆品</a></li>
        				<li><a class="ajax_top" id="ajax_cat_40" href="javascript:server(40,1);">销量Top100</a></li>
        				<li><a class="ajax_top" id="ajax_cat_50" href="javascript:server(50,1);">品牌推荐</a></li>
        				<li><a class="ajax_top" id="ajax_cat_60" href="javascript:server(60,1);">金牌卖家</a>
        				</li>
        				<li><a class="ajax_top" id="ajax_cat_70" href="javascript:server(70,1);">9.9块</a></li>
        				<li><a class="ajax_top" id="ajax_cat_80" href="javascript:server(80,1);">29.9块</a></li>
        				<li><a class="ajax_top" id="ajax_cat_90" href="javascript:server(90,1);">49.9块</a></li> 
						<li><a class="ajax_top" id="ajax_cat_100" href="javascript:server(100,1);">99.9快</a></li>
        				
						
        			</ul>
        		</div>
        		<form class="index_searchBox" action="<?php echo U('Cid/search');?>" method="post">
					<input name="keywords" class="index_searchBoxInput" placeholder="请输入要查找优惠卷的商品名称…" style="color: rgb(156, 154, 156);" type="text" _hover-ignore="1">
					<input name="" class="index_searchBoxButton" value="搜索" type="submit">
        		</form>
        		
        	</div>
        	<div class="category_foot">
				<div class="category_menu">
					<a class="ajax_cat active" id="ajax_cat_0" href="javascript:server(0,1);">全部</a>
					<a class="ajax_cat" id="ajax_cat_1" href="javascript:server(1,1);">女装</a>
					<a class="ajax_cat" id="ajax_cat_2" href="javascript:server(2,1);">男装</a>
					<a class="ajax_cat" id="ajax_cat_3" href="javascript:server(3,1);">内衣</a>
					<a class="ajax_cat" id="ajax_cat_4" href="javascript:server(4,1);">母婴</a>
					<a class="ajax_cat" id="ajax_cat_5" href="javascript:server(5,1);">包包</a>
					<a class="ajax_cat" id="ajax_cat_7" href="javascript:server(7,1);">居家</a>
					<a class="ajax_cat" id="ajax_cat_8" href="javascript:server(8,1);">鞋品</a>
					<a class="ajax_cat" id="ajax_cat_9" href="javascript:server(9,1);">美食</a>
					<a class="ajax_cat" id="ajax_cat_10" href="javascript:server(10,1);">文体</a>
					<a class="ajax_cat" id="ajax_cat_11" href="javascript:server(11,1);">家电</a>
					<a class="ajax_cat" id="ajax_cat_13" href="javascript:server(13,1);">配饰</a>
					<a class="ajax_cat" id="ajax_cat_14" href="javascript:server(14,1);">数码</a>
					<a class="ajax_cat" id="ajax_cat_12" href="javascript:server(12,1);">其他</a>
				</div>
				<div class="category_page" id="cat_ajax">
						<a id="last_page" href="javascript:server(0,1);">上一页</a>
						<a id="next_page" href="javascript:server(0,1);">下一页</a>
				</div>
        	</div>
			
        </div>

		<div id="body_ajax">
			<div class="goods-list wrap">
				<ul class="clearfix">

				<?php if(is_array($datas)): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?><li class="g_over">
						<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?> class="img" target="_blank">
							<?php if(($data['shop_type']) == 'B'): ?><i class="index_tmall"></i>
							<?php else: ?><i class="index_taobao"></i><?php endif; ?>
							<img alt=<?php echo ($data['oldtitle']); ?> class="wsgw-lazy" src=<?php echo ($data['pic_url']); ?>  data-original=<?php echo ($data['pic_url']); ?>>
						</a>
						<div class="goods-padding">
							<div class="coupon-wrap clearfix">
								<span class="price"><b><i>￥</i><?php echo ($data['coupon_quan_price']); ?></b> 券后价</span>
								<span class="old-price"><i>￥</i><?php echo ($data['coupon_price']); ?></span>
								<span class="coupon"><em class="quan-left"></em>券<b><i>￥</i><?php echo ($data['quan']); ?></b><em class="quan-right"></em></span>
							</div>
							<div class="title">
								<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?>>
									<?php echo ($data['title']); ?>
								</a>
							</div>
							<div class="product-box">
		                        <div class="produt_fl">
			                        <div class="goods-num-type">
			                        	<span class="goods-num">销量<b><?php echo ($data['volume']); ?></b></span>
			                        </div>
			                        <div class="sale-title clearfix">
			                            <span class="product-label">
			                            	<span class="con">有效时间</span><i class="i-right"></i>
			                            </span>
			                            <span class="sale-title-font pline"><?php echo (date("m.d",$data['coupon_start_time'])); ?>-<?php echo (date("m.d",$data['coupon_end_time'])); ?></span>
			                        </div>
			                    </div>
			                    <div class="produt_fr">
			                        <a href=<?php echo ($data['diadurl']); ?> target="_blank" title=<?php echo ($data['title']); ?>>领券购买</a>
			                    </div>
		                    </div>
						</div>   
					</li><?php endforeach; endif; else: echo "" ;endif; ?>

				</ul>
			</div>
		</div>
	</div>
	<div class="index_link wrap">			
		<ul class="sideBar" id="sideBar" style="display: none;">
			<li><a href="javascript:scrollGo(0);"><i class="icon_sideBar_4"></i><span>返回<br>顶部</span></a></li>
		</ul>
		<div class="app_code">
		    <div class="app_android">
		        <i></i>
		        <span>下载<br>APP</span>
		        <div class="appcode"><img src="themes/5395_l/images/app_code.jpg"></div>
		    </div>
		</div>
		<div class="index_footer">
			<div class="wrap">
				<span>Copyright@2014 版权所有 5395.COM</span>
				<em>沪ICP备14004334号-1</em>
			</div>
		</div>
		<div style="display:none;"></div>
	</div>
	<script type="text/javascript">
		$('.wsgw-lazy').lazyload();
		$(".listNav2").hide();
	</script>
	<script type="text/javascript">
		jQuery(".slideBox").slide({mainCell:".bd ul",autoPlay:true,interTime:4000});
	</script>
	<script type="text/javascript">
		function go_f(fid){
			$("html,body").animate({scrollTop:$("#f"+fid).offset().top},1000);
		}
	</script>
	
	<script type="text/javascript">

		function server(cat_id,page_id){			
			$("html,body").animate({scrollTop:$(".index_jxtm").offset().top},1000);
			$.ajax({  
					type : "GET",  
					url : "<?php echo U('ajaxGet');?>",
					data: {cat_id:cat_id , page: page_id},  
					dataType:"json",					
					
					success : function(data){ 
						$("#ajax_total").replaceWith("<div id='ajax_total'>"+data+"</div>");
						$(".ajax_top").removeClass("active");
						$(".ajax_cat").removeClass("active");				
						$("#ajax_cat_"+cat_id).addClass('active');
						
						$('.wsgw-lazy').lazyload();
					}
			});
		}
	</script>


	<a title="返回顶部" id="go-top" href="#" style="position: fixed; right: 85px; top: 184px; display: none;">
	</a>
</body>
</html>