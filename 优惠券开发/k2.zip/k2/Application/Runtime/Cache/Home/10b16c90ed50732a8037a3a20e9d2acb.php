<?php if (!defined('THINK_PATH')) exit();?><html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>淘宝客程序,淘宝客免费源码,淘宝优惠券代码,淘宝客网站下载</title>
	<meta name="Keywords" content="淘宝优惠券源码,淘宝客源码下载,淘宝客程序,淘宝客网站,淘宝客网站代码下载">
	<meta name="Description" content="2017最新淘客宝网站优惠券程序,3W多个商品无需API自动采集,全网原创淘客程序免费源码下载">
	<script src="//alimama.alicdn.com/tkapi/plugin.js?_t=20130226.js" async="" charset="utf-8" mod_name="tkapi-plugin"></script>
	<script src="//alimama.alicdn.com/tkapi/click.js?_t=20130226.js" async="" charset="utf-8" mod_name="tkapi-click"></script>
	<script src="https://hm.baidu.com/hm.js?d742034f17d764760810e1dd5e89a698"></script>
	<script charset="gbk" async="" src="http://a.alimama.cn/tkapi.js"></script>
	<script charset="gbk" async="" src="http://a.alimama.cn/tkapi.js"></script>
	<link href="/k2/Public/css/global.css" rel="stylesheet" type="text/css">
	<link href="/k2/Public/css/index.css" rel="stylesheet" type="text/css">
	<link href="/k2/Public/css/newcommontwo.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="/k2/Public/js/jquery.js"></script> 
	<script type="text/javascript" src="/k2/Public/js/global.js"></script>
	<script type="text/javascript" src="/k2/Public/js/go-top.js"></script>
	<script type="text/javascript" src="/k2/Public/js/globalv.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.SuperSlide.js"></script>
	<script type="text/javascript" src="/k2/Public/js/index.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.lazyload.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jq.cookie.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jq.popup.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.dlzc.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/masonry.min.js"></script>
	<script type="text/javascript" src="/k2/Public/js/jquery.infinitescroll.min.js"></script>
	<script>
	$(function(){
		window.onscroll = function(){
			var a = document.documentElement.scrollTop || document.body.scrollTop;  
			if( a >= 328 ) { 
				$('.cat-wrap').addClass('cat-wrap-1'); 
			} else { 
				$('.cat-wrap').removeClass('cat-wrap-1'); 
			}
		}
	})
	</script>
	
	<style type="text/css">
		.list ul{float:left;}
		.ctips{text-align:center;}
		.ico1,.ico2{display:block;float:left;width:10px;}
		.ico1{background:url("/static/images/Sort.gif") no-repeat scroll left 16px rgba(0, 0, 0, 0);}
		.ico2{background:url("/static/images/Sort.gif") no-repeat scroll -10px 16px rgba(0, 0, 0, 0);}
	</style>
</head>

<body>
	<div class="headerBar" _hover-ignore="1">
		<div class="wrap">
			<style>
				.fr {
				    float: right;
				}
				.fl {
				    float: left;
				}

				.headerBar{height:35px;line-height:35px;font-size:12px;background:#F2F2F2;}
				.headerBarNav{}
				.headerBarNav li{float:left;}
				.headerBarNav a{display:block;padding:0 10px;}
				.headerBarNav a:hover .icon_1{background-position:0 -16px;}
				.headerBarNav a:hover .icon_2{background-position:-16px -16px;}
				.headerBarNav a:hover .icon_3{background-position:-32px -16px;}
				.headerBarNav i{float:left;width:16px;height:16px;margin:9px 2px 0 0;}
				.headerBarNav .h:link,.headerBarNav .h:visited{color:#EC425B;}
				.header_fl{color:#333;float:left;}
				.header_fr{float:right;}
				.header_fl a{color:#ed145b}
				.header_fl a:hover{text-decoration:underline;}

			</style>
			
	    </div>
	</div>

	<div class="header">
		<div class="wrap">
			<h1><a style="width:390px;" href="http://www.5395.com/" class="logo" title="5395网上购物" _hover-ignore="1">5395网上购物</a></h1>
			<div class="headerR"><img src="/static/5395_150306/images/headerR.png"></div>
			<div class="index_search">
				<form class="searchBox" action="<?php echo U('Cid/search');?>" method="post">
					<input name="keywords" class="searchBoxInput" placeholder="请输入要查找优惠卷的商品名称…" style="color: rgb(156, 154, 156);" type="text">
					<input name="" class="searchBoxButton" value="搜索" type="submit">
				</form>
				<div class="index_kjgjc">
					<a href="http://www.5395.com/item/quan.php?keywords=连衣裙" target="blank">连衣裙</a>
					<a href="http://www.5395.com/item/quan.php?keywords=男鞋" target="blank">男鞋</a>
					<a href="http://www.5395.com/item/quan.php?keywords=女鞋" target="blank"> 女鞋</a>
					<a href="http://www.5395.com/item/quan.php?keywords=中老年女装" target="blank">中老年女装</a>
					<a href="http://www.5395.com/item/quan.php?keywords=T恤" target="blank">T恤</a>
					<a href="http://www.5395.com/item/quan.php?keywords=雪纺衫" target="blank">雪纺衫</a>
					<a href="http://www.5395.com/item/quan.php?keywords=孕妇装" target="blank">孕妇装</a>
					<a href="http://www.5395.com/item/quan.php?keywords=女包" target="blank">女包</a>
					<a href="http://www.5395.com/item/quan.php?keywords=运动套装" target="blank">运动套装</a>
					<a href="http://www.5395.com/item/quan.php?keywords=牛仔裤" target="blank">牛仔裤</a>
				</div>
			</div>	
		</div>
	</div>
	<div class="nav">
		<div class="wrap">
			<ul>
				<?php if(is_array($flags)): $i = 0; $__LIST__ = $flags;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li
					<?php if($vo['controllername'] == $name): ?>class="on"<?php endif; ?> 

				><a href=<?php echo ($vo['url']); ?>  target="blank">
						<?php echo ($vo['name']); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>

	<div class="wrap">
		<div id= "ajaxPart">
			<!--<div class="promise"></div>-->
			<div class="cat-wrap wrap">
					<div class="cat-list clearfix">
						<span class="cat-lit-title">商品分类</span>
						<input type="hidden" id="indexCid" value=<?php echo ($cid); ?>>
						<ul class="clearfix">
							<li >
								<a class="ajax_cid" id="ajax_cat_0" href="javascript:getticket(0,1,0);">全部优惠</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_1" href="javascript:getticket(0,1,1);">女装</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_2" href="javascript:getticket(0,1,2);">男装</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_3" href="javascript:getticket(0,1,3);">内衣</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_4" href="javascript:getticket(0,1,4);">母婴</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_5" href="javascript:getticket(0,1,5);">包包</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_7" href="javascript:getticket(0,1,7);">居家</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_8" href="javascript:getticket(0,1,8);">鞋品</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_9" href="javascript:getticket(0,1,9);">美食</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_10" href="javascript:getticket(0,1,10);">文体</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_11" href="javascript:getticket(0,1,11);">家电</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_13" href="javascript:getticket(0,1,13);">配饰</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_14" href="javascript:getticket(0,1,14);">数码</a>
							</li>
							<li >
								<a class="ajax_cid" id="ajax_cat_12" href="javascript:getticket(0,1,12);">其他</a>
							</li>											
						</ul>
						
                    </div>

					<div class="cat-list sale-type clearfix">
						<span class="cat-lit-title">价格分类</span>
						<ul class="clearfix">
							<li><a class="ajax_ticket" id="ajax_ticket_1" href="javascript:getticket(1,1,<?php echo ($cid); ?>);">大于100元</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_2" href="javascript:getticket(2,1,<?php echo ($cid); ?>);">50-100元</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_3" href="javascript:getticket(3,1,<?php echo ($cid); ?>);">30-50元</a></li> 
							<li><a class="ajax_ticket" id="ajax_ticket_4" href="javascript:getticket(4,1,<?php echo ($cid); ?>);">10-30元</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_5" href="javascript:getticket(5,1,<?php echo ($cid); ?>);">10元以下</a></li>
						</ul>
					</div>
			</div>
	
			<div class="goods-list wrap">
				<ul class="clearfix">

				<?php if(is_array($datas)): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?><li class="g_over">
						<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?> class="img" target="_blank">
							<?php if(($data['shop_type']) == 'B'): ?><i class="index_tmall"></i>
							<?php else: ?><i class="index_taobao"></i><?php endif; ?>
							<img alt=<?php echo ($data['oldtitle']); ?> class="wsgw-lazy" src=<?php echo ($data['pic_url']); ?>  data-original=<?php echo ($data['pic_url']); ?>>
						</a>
						<div class="goods-padding">
							<div class="coupon-wrap clearfix">
								<span class="price"><b><i>￥</i><?php echo ($data['coupon_quan_price']); ?></b> 券后价</span>
								<span class="old-price"><i>￥</i><?php echo ($data['coupon_price']); ?></span>
								<span class="coupon"><em class="quan-left"></em>券<b><i>￥</i><?php echo ($data['quan']); ?></b><em class="quan-right"></em></span>
							</div>
							<div class="title">
								<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?>>
									<?php echo ($data['title']); ?>
								</a>
							</div>
							<div class="product-box">
		                        <div class="produt_fl">
			                        <div class="goods-num-type">
			                        	<span class="goods-num">销量<b><?php echo ($data['volume']); ?></b></span>
			                        </div>
			                        <div class="sale-title clearfix">
			                            <span class="product-label">
			                            	<span class="con">有效时间</span><i class="i-right"></i>
			                            </span>
			                            <span class="sale-title-font pline"><?php echo (date("m.d",$data['coupon_start_time'])); ?>-<?php echo (date("m.d",$data['coupon_end_time'])); ?></span>
			                        </div>
			                    </div>
			                    <div class="produt_fr">
			                        <a href=<?php echo ($data['diadurl']); ?> target="_blank" title=<?php echo ($data['title']); ?>>领券购买</a>
			                    </div>
		                    </div>
						</div>   
					</li><?php endforeach; endif; else: echo "" ;endif; ?>
									
		 	</div>
		
				<?php echo ($page); ?>
</div>

<script type="text/javascript">

		$(document).ready(function(){   
     		var cidNum = $("#indexCid").val();
     		$("#ajax_cat_"+cidNum).parent().addClass('active');   
		});  
		
		function getticket(ticket_id,page_id,cat_id){
			$("html,body").animate({scrollTop:$(".index_kjgjc").offset().top},1000);
			$.ajax({  
					type : "GET",  
					url : "<?php echo U('ajaxGet02');?>",
					data: {cat_id:cat_id , page: page_id , ticket_id:ticket_id},  
					dataType:"json",
					success : function(data){  
						$("#ajaxPart").replaceWith(data);
						var cat = cat_id;
						var ticket = ticket_id;
						$(".ajax_cid").parent().removeClass("active");
						$(".ajax_ticket").parent().removeClass("active");
						$("#ajax_cat_"+cat).parent().addClass('active');
						$("#ajax_ticket_"+ticket).parent().addClass('active');						
						$('.wsgw-lazy').lazyload();
					}
			});
		}

		function jump_page(){
			var cat_id = $("#cidNumber").val();
			var ticket_id = $("#ticketNumber").val();
			var page_id = $("#go_page").val();
			getticket(ticket_id,page_id,cat_id);
		}
</script>

<ul class="sideBar" id="sideBar" style="display: none;">
		<!--<li><a href="#"><i class="icon_sideBar_1"></i><span>商家<br />报名</a></span></li>
		<li><a href="/u/home.php"><i class="icon_sideBar_2"></i><span>立即<br />签到</a></span></li>
		<li><a href="/feedBack.php"><i class="icon_sideBar_3"></i><span>意见<br />反馈</a></span></li>-->
		<li><a href="javascript:scrollGo(0);"><i class="icon_sideBar_4"></i><span>返回<br>顶部</span></a></li>
	</ul>
	<div class="app_code">
	    <div class="app_android">
	        <i></i>
	        <span>下载<br>APP</span>
	        <div class="appcode"><img src="/themes/5395_l/images/app_code.jpg"></div>
	    </div>
	</div>
</div>
		<div class="index_footer">
			<div class="wrap">
				<span>Copyright@2014 版权所有 5395.COM</span>
				<em>沪ICP备14004334号-1</em>
			</div>
		</div>
	<div style="display:none;"></div>


	<a title="返回顶部" id="go-top" href="#" style="position: fixed; right: 85px; top: 5472px;"></a>

	

</body>
</html>