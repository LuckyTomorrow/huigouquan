<?php if (!defined('THINK_PATH')) exit();?>		<div class="index_category wrap">
        	<div class="category_top">
        		<div class="category_menu">
        			<ul>
        				<li><a class="ajax_top" id="ajax_cat_30" href="javascript:server(30,1);">今日爆品</a></li>
        				<li><a class="ajax_top" id="ajax_cat_40" href="javascript:server(40,1);">销量Top100</a></li>
        				<li><a class="ajax_top" id="ajax_cat_50" href="javascript:server(50,1);">品牌推荐</a></li>
        				<li><a class="ajax_top" id="ajax_cat_60" href="javascript:server(60,1);">金牌卖家</a>
        				</li>
        				<li><a class="ajax_top" id="ajax_cat_70" href="javascript:server(70,1);">9.9块</a></li>
        				<li><a class="ajax_top" id="ajax_cat_80" href="javascript:server(80,1);">29.9块</a></li>
        				<li><a class="ajax_top" id="ajax_cat_90" href="javascript:server(90,1);">49.9块</a></li> 
						<li><a class="ajax_top" id="ajax_cat_100" href="javascript:server(100,1);">99.9快</a></li>
        				
        			</ul>
        		</div>
        		<form class="index_searchBox" action="<?php echo U('Cid/search');?>" method="post">
					<input name="keywords" class="index_searchBoxInput" placeholder="请输入要查找优惠卷的商品名称…" style="color: rgb(156, 154, 156);" type="text" _hover-ignore="1">
					<input name="" class="index_searchBoxButton" value="" type="submit">
        		</form>
        		
        	</div>
        	<div class="category_foot">
				<div class="category_menu">
					<a class="ajax_cat active" id="ajax_cat_0" href="javascript:server(0,1);">全部</a>
					<a class="ajax_cat" id="ajax_cat_1" href="javascript:server(1,1);">女装</a>
					<a class="ajax_cat" id="ajax_cat_2" href="javascript:server(2,1);">男装</a>
					<a class="ajax_cat" id="ajax_cat_3" href="javascript:server(3,1);">内衣</a>
					<a class="ajax_cat" id="ajax_cat_4" href="javascript:server(4,1);">母婴</a>
					<a class="ajax_cat" id="ajax_cat_5" href="javascript:server(5,1);">包包</a>
					<a class="ajax_cat" id="ajax_cat_7" href="javascript:server(7,1);">居家</a>
					<a class="ajax_cat" id="ajax_cat_8" href="javascript:server(8,1);">鞋品</a>
					<a class="ajax_cat" id="ajax_cat_9" href="javascript:server(9,1);">美食</a>
					<a class="ajax_cat" id="ajax_cat_10" href="javascript:server(10,1);">文体</a>
					<a class="ajax_cat" id="ajax_cat_11" href="javascript:server(11,1);">家电</a>
					<a class="ajax_cat" id="ajax_cat_13" href="javascript:server(13,1);">配饰</a>
					<a class="ajax_cat" id="ajax_cat_14" href="javascript:server(14,1);">数码</a>
					<a class="ajax_cat" id="ajax_cat_12" href="javascript:server(12,1);">其他</a>
				</div>
						<?php echo ($page); ?>
        	</div>
			
        </div>
		<div id="body_ajax">
			<div class="goods-list wrap">
				<ul class="clearfix">

				<?php if(is_array($datas)): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?><li class="g_over">
						<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?> class="img" target="_blank">
							<?php if(($data['shop_type']) == 'B'): ?><i class="index_tmall"></i>
							<?php else: ?><i class="index_taobao"></i><?php endif; ?>
							<img alt=<?php echo ($data['oldtitle']); ?> class="wsgw-lazy" src=<?php echo ($data['pic_url']); ?>  data-original=<?php echo ($data['pic_url']); ?>>
						</a>
						<div class="goods-padding">
							<div class="coupon-wrap clearfix">
								<span class="price"><b><i>￥</i><?php echo ($data['coupon_quan_price']); ?></b> 券后价</span>
								<span class="old-price"><i>￥</i><?php echo ($data['coupon_price']); ?></span>
								<span class="coupon"><em class="quan-left"></em>券<b><i>￥</i><?php echo ($data['quan']); ?></b><em class="quan-right"></em></span>
							</div>
							<div class="title">
								<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?>>
									<?php echo ($data['title']); ?>
								</a>
							</div>
							<div class="product-box">
		                        <div class="produt_fl">
			                        <div class="goods-num-type">
			                        	<span class="goods-num">销量<b><?php echo ($data['volume']); ?></b></span>
			                        </div>
			                        <div class="sale-title clearfix">
			                            <span class="product-label">
			                            	<span class="con">有效时间</span><i class="i-right"></i>
			                            </span>
			                            <span class="sale-title-font pline"><?php echo (date("m.d",$data['coupon_start_time'])); ?>-<?php echo (date("m.
			                            d",$data['coupon_end_time'])); ?></span>
			                        </div>
			                    </div>
			                    <div class="produt_fr">
			                        <a href=<?php echo ($data['diadurl']); ?> target="_blank" title=<?php echo ($data['title']); ?>>领券购买</a>
			                    </div>
		                    </div>
						</div>   
					</li><?php endforeach; endif; else: echo "" ;endif; ?>

				</ul>
			</div>
		</div>