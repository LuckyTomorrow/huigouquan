<?php if (!defined('THINK_PATH')) exit();?>		<div id= "ajaxPart">
			<!--<div class="promise"></div>-->
			<div class="cat-wrap wrap">
					<div class="cat-list clearfix">
						<span class="cat-lit-title">搜索结果</span>
						<ul class="clearfix">
							<li >
								<input type="hidden" id="keys" value = <?php echo ($keyword); ?>>
								<span style="color: red;">"<?php echo ($keyword); ?>"</span> , 相关商品有<?php echo ($count); ?>件
							</li>
																	
						</ul>
						
                    </div>
					<div class="cat-list sale-type clearfix">
						<span class="cat-lit-title">价格分类</span>
						<ul class="clearfix">
							<li><a class="ajax_ticket" id="ajax_ticket_0" href="javascript:searchKW(0,1);">全部优惠</a></li>
							<li><a class="ajax_ticket" id="ajax_ticket_1" href="javascript:searchKW(1,1);">大于100元</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_2" href="javascript:searchKW(2,1);">50-100元</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_3" href="javascript:searchKW(3,1);">30-50元</a></li> 
							<li><a class="ajax_ticket" id="ajax_ticket_4" href="javascript:searchKW(4,1);">10-30元</a></li>
        					<li><a class="ajax_ticket" id="ajax_ticket_5" href="javascript:searchKW(5,1);">10元以下</a></li>
						</ul>
					</div>
			</div>
	
			<div class="goods-list wrap">
				<ul class="clearfix">

				<?php if(is_array($datas)): $i = 0; $__LIST__ = $datas;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$data): $mod = ($i % 2 );++$i;?><li class="g_over">
						<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?> class="img" target="_blank">
							<?php if(($data['shop_type']) == 'B'): ?><i class="index_tmall"></i>
							<?php else: ?><i class="index_taobao"></i><?php endif; ?>
							<img alt=<?php echo ($data['oldtitle']); ?> class="wsgw-lazy" src=<?php echo ($data['pic_url']); ?>  data-original=<?php echo ($data['pic_url']); ?>>
						</a>
						<div class="goods-padding">
							<div class="coupon-wrap clearfix">
								<span class="price"><b><i>￥</i><?php echo ($data['coupon_quan_price']); ?></b> 券后价</span>
								<span class="old-price"><i>￥</i><?php echo ($data['coupon_price']); ?></span>
								<span class="coupon"><em class="quan-left"></em>券<b><i>￥</i><?php echo ($data['quan']); ?></b><em class="quan-right"></em></span>
							</div>
							<div class="title">
								<a href="<?php echo ($data['diadurl']); ?>" title=<?php echo ($data['title']); ?>>
									<?php echo ($data['title']); ?>
								</a>
							</div>
							<div class="product-box">
		                        <div class="produt_fl">
			                        <div class="goods-num-type">
			                        	<span class="goods-num">销量<b><?php echo ($data['volume']); ?></b></span>
			                        </div>
			                        <div class="sale-title clearfix">
			                            <span class="product-label">
			                            	<span class="con">有效时间</span><i class="i-right"></i>
			                            </span>
			                            <span class="sale-title-font pline"><?php echo (date("m.d",$data['coupon_start_time'])); ?>-<?php echo (date("m.d",$data['coupon_end_time'])); ?></span>
			                        </div>
			                    </div>
			                    <div class="produt_fr">
			                        <a href=<?php echo ($data['diadurl']); ?> target="_blank" title=<?php echo ($data['title']); ?>>领券购买</a>
			                    </div>
		                    </div>
						</div>   
					</li><?php endforeach; endif; else: echo "" ;endif; ?>
									
		 	</div>
		
				<?php echo ($page); ?>
		</div>