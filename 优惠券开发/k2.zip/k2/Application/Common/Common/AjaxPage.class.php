<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2009 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id: Page.class.php 2712 2012-02-06 10:12:49Z liu21st $
namespace Common\Common;
class AjaxPage {
    // 分页栏每页显示的页数
    public $rollPage = 5;
    
    // 默认列表每页显示行数
    public $listRows = 20;
    // 起始行数
    public $firstRow ;
    // 分页总页面数
    protected $totalPages  ;
    // 总行数
    protected $totalRows  ;
    // 当前页数
    protected $nowPage    ;
    // 分页栏的总数
    protected $coolPages   ;
    // 分页显示定制
    protected $config  = array('header'=>'条记录','prev'=>'上一页','next'=>'下一页','first'=>'第一页','last'=>'最后一页','theme'=>' %totalRow% %header% %nowPage%/%totalPage% 页 %upPage% %downPage% %first%  %prePage%  %linkPage%  %nextPage% %end%');
    // 默认分页变量名称
    protected $varPage;

    //初始化时，计算出当前页数和起始行数
    public function __construct($totalRows,$listRows=20,$ajax_func='server') {
        $this->totalRows = $totalRows;  //总记录数
        $this->ajax_func = $ajax_func;  //对应js的ajax功能函数名
        
        //page参数名字获取，如果config文件有定义则取config，没有，则默认为“page” 
        $this->varPage = C('VAR_PAGE') ? C('VAR_PAGE') : 'page' ;
        $this->listRows = intval($listRows);

        //计算总页数，向上取整
        $this->totalPages = ceil($this->totalRows/$this->listRows);     
        //计算分栏数，用于比如每隔5页向前向后跳转
        $this->coolPages  = ceil($this->totalPages/$this->rollPage);

        //如果url中没有var_page参数，则默认为第一页处理
        $this->nowPage  = !empty($_GET[$this->varPage])?intval($_GET[$this->varPage]):1;

        //防呆处理:如果当前页大于总页数，则将总页数值赋值给当前页（常发生于在当前页为最后一页时按“下一页”操作）
        if(!empty($this->totalPages) && ($this->nowPage > $this->totalPages) ){
            $this->nowPage = $this->totalPages;
        }

        //当前页的起始行数，本应该是要加1才是当前页的第一行
        //但考虑该属性是用于limit(n,m)方法的第一个参数，也即跳过n行取m行的意思
        //故这里的实际效果是当前页的上一页尾行的行号
        $this->firstRow = $this->listRows*($this->nowPage-1) ;
    }

    //修改config参数
    public function setConfig($name,$value) {
        if(isset($this->config[$name])) {
            $this->config[$name]    =   $value;
        }
    }

    //根据当前页，计算得到分页相关格式和数据字符串
    public function show() {
        //如果没有数据，返回空
        if(0 == $this->totalRows) return '';

        //获取page参数名
        $p = $this->varPage;
        //获取当前页在哪个分栏中，如总页数25，分栏每页为5，则有5个分栏，那21在第五个分栏处
        $nowCoolPage      = ceil($this->nowPage/$this->rollPage);

        //上下翻页字符串
        $upRow   = $this->nowPage-1;
        $downRow = $this->nowPage+1;
        if ($upRow>=1){
            $upPage="<a class='ajaxify' id='big' href='JavaScript:".$this->ajax_func."(".$upRow.")'>".$this->config['prev']."</a>";
        }else{
            //当前页为第一页时，“上一页”的样式与内容消失
            $upPage="";
        }

        if ($downRow <= $this->totalPages){
            $downPage="<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(".$downRow.")'>".$this->config['next']."</a>";
        }else{
            //当前页为尾页时，“下一页”的样式与内容消失
            $downPage="";
        }
        // << < > >>   首页 上一分栏 下一分栏 尾页
        // 假设每隔5页分栏，如果当前页在第五页，说明已经在第一分栏，则“首页 上一分栏”的样式和内容消失
        if($nowCoolPage == 1){
            $theFirst = "<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(1)' >".$this->config['first']."</a>";
            $prePage = "";
        }else{
            //上一分栏页数 = 当前页 - 每一分栏页数
            $preRow =  $this->nowPage - $this->rollPage;
            $prePage = "<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(".$preRow.")'>上".$this->rollPage."页</a>";
            $theFirst = "<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(1)' >".$this->config['first']."</a>";
        }
        //如果当前页所在分栏是最后分栏，则“下一分栏 尾页”的样式和内容消失
        if($nowCoolPage == $this->coolPages){
            $nextPage = "";
            $theEndRow = $this->totalPages;
            $theEnd="<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(".$theEndRow.")' >".$this->config['last']."</a>";
        }else{
            //下一分栏页数 = 当前页 + 每一分栏页数
            $nextRow = $this->nowPage + $this->rollPage;
            $theEndRow = $this->totalPages;
            $nextPage = "<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(".$nextRow.")' >下".$this->rollPage."页</a>";
            $theEnd = "<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(".$theEndRow.")' >".$this->config['last']."</a>";
        }
        // 1 2 3 4 5
        $linkPage = "";
        for($i=1;$i<=$this->rollPage;$i++){
            //假设当前页为23，总页数25，分页每页5
            //则当前栏数为5，$page从21开始到25
            $page=($nowCoolPage-1)*$this->rollPage+$i;
            //如果不为当前页
            if($page!=$this->nowPage){
                //$page不超过总页数，该判断是用于防止总页数少于$rollPage的情况
                if($page<=$this->totalPages){
                   $linkPage .= "&nbsp;<a class='ajaxify' id='big' href='javascript:".$this->ajax_func."(".$page.")'>&nbsp;".$page."&nbsp;</a>";
                }else{
                    break;
                }
            }else{
                //如果总页数为1，则不显示任何样式和内容
                if($this->totalPages != 1){
                    $linkPage .= "&nbsp;<span class='current'>".$page."</span>";
                }
            }
        }
        $pageStr  =  str_replace(  
            array('%totalRow%','%header%','%nowPage%','%totalPage%','%upPage%','%downPage%','%first%','%prePage%','%linkPage%','%nextPage%','%end%'),
            array($this->totalRows,$this->config['header'],$this->nowPage,$this->totalPages,$upPage,$downPage,$theFirst,$prePage,$linkPage,$nextPage,$theEnd),
            $this->config['theme']
        ); 

        return $pageStr;
    }

}

?>