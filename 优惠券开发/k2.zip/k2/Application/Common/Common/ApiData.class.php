<?php
namespace Common\Common;

class ApiData{

	//get方式的CURl获取相关数据
	function httpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($curl, CURLOPT_URL, $url);
 
    $res = curl_exec($curl);
    curl_close($curl);
    return $res;
	}

	
	function httpPost($url,$data=null){ // 模拟提交数据函数      
	    $curl = curl_init(); // 启动一个CURL会话      
	    curl_setopt($curl, CURLOPT_URL, $url); // 要访问的地址                  
	    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查      
	    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 1); // 从证书中检查SSL加密算法是否存在      
	    curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']); // 模拟用户使用的浏览器      
	    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1); // 使用自动跳转      
	    curl_setopt($curl, CURLOPT_AUTOREFERER, 1); // 自动设置Referer      
	    curl_setopt($curl, CURLOPT_POST, 1); // 发送一个常规的Post请求      
	    curl_setopt($curl, CURLOPT_POSTFIELDS, $data); // Post提交的数据包      
	    
	    curl_setopt($curl, CURLOPT_TIMEOUT, 30); // 设置超时限制防止死循环      
	    curl_setopt($curl, CURLOPT_HEADER, 0); // 显示返回的Header区域内容      
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1); // 获取的信息以文件流的形式返回      
	    $tmpInfo = curl_exec($curl); // 执行操作      
	    if (curl_errno($curl)) {      
	       echo 'Errno'.curl_error($curl);      
	    }      
	    curl_close($curl); // 关键CURL会话      
	    return $tmpInfo; // 返回数据      
	} 

	function getDatas($url){
		
    	$datas = $this->httpGet($url);
    	$datas = json_decode($datas);
    	if(empty($datas)){
    		return;
    	}
    	
    	$arrs = null;
    	for($i=0;$i<count($datas);$i++){  
    		if(is_object($datas[$i])) { 
        		$datas[$i] = (array)$datas[$i]; 
        	} 

    		$arrs[$i]['num_iid'] = $datas[$i]['num_iid'];
    		$arrs[$i]['title'] = $datas[$i]['title'];
    		$arrs[$i]['star_pp'] = $datas[$i]['star_pp'];
    		$arrs[$i]['cid'] = $datas[$i]['cid'];
    		$arrs[$i]['oldtitle'] = $datas[$i]['oldtitle'];
    		$arrs[$i]['pic_url'] = $datas[$i]['pic_url'];

    		$arrs[$i]['video'] = $datas[$i]['video'];
    		$arrs[$i]['gtype'] = $datas[$i]['gtype'];
    		$arrs[$i]['campaignid'] = $datas[$i]['campaignid'];
    		$arrs[$i]['shopkeeperid'] = $datas[$i]['shopkeeperid'];
    		$arrs[$i]['activity_id'] = $datas[$i]['activity_id'];
    		$arrs[$i]['sellerId'] = $datas[$i]['sellerId'];
    		$arrs[$i]['coupon_price'] = $datas[$i]['coupon_price'];

    		$arrs[$i]['quan'] = $datas[$i]['quan'];
    		$arrs[$i]['volume'] = $datas[$i]['volume'];
    		$arrs[$i]['isjhs'] = $datas[$i]['isjhs'];
    		$arrs[$i]['istqg'] = $datas[$i]['istqg'];
    		$arrs[$i]['count'] = $datas[$i]['count'];
    		$arrs[$i]['rest'] = $datas[$i]['rest'];
    		$arrs[$i]['onlines'] = $datas[$i]['onlines'];

    		$arrs[$i]['shop_type'] = $datas[$i]['shop_type'];
    		$arrs[$i]['ishaiwai'] = $datas[$i]['ishaiwai'];
    		$arrs[$i]['isau'] = $datas[$i]['isau'];
    		$arrs[$i]['quan_hour'] = $datas[$i]['quan_hour'];
    		$arrs[$i]['volume_hour'] = $datas[$i]['volume_hour'];
    		$arrs[$i]['volume_hour2'] = $datas[$i]['volume_hour2'];
    		$arrs[$i]['volume_hourtd'] = $datas[$i]['volume_hourtd'];
    		$arrs[$i]['commission_rate'] = $datas[$i]['commission_rate'];
    		$arrs[$i]['intro'] = $datas[$i]['intro'];
    		$arrs[$i]['wenan_img'] = $datas[$i]['wenan_img'];
    		$arrs[$i]['quanurl'] = $datas[$i]['quanurl'];
    		$arrs[$i]['diadurl'] = $datas[$i]['diadurl'];
    		$arrs[$i]['coupon_quan_price'] = $datas[$i]['coupon_quan_price'];
    		$arrs[$i]['coupon_start_time'] = $datas[$i]['coupon_start_time'];
    		$arrs[$i]['coupon_end_time'] = $datas[$i]['coupon_end_time'];
    		$arrs[$i]['shop_type'] = $datas[$i]['shop_type'];
    		$arrs[$i]['add_time'] = $datas[$i]['add_time'];

    	}

    	return $arrs;
	}

}



?>