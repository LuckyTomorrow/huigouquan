<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2009 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
// $Id: Page.class.php 2712 2012-02-06 10:12:49Z liu21st $
namespace Home\Common;
class TotalAjaxPage {
    // 分页栏每页显示的页数
    public $rollPage = 5;
    
    // 默认列表每页显示行数
    public $listRows = 20;
    // 起始行数
    public $firstRow ;
    // 分页总页面数
    public $totalPages  ;
    // 总行数
    public $totalRows  ;
    //商品分类号(个人定制功能)
    public $cat_id ;
    //优惠券分类号(个人定制功能)
    public $ticket_id ;
    // 当前页数
    public $nowPage    ;
    // 分页栏的总数
    public $coolPages   ;
    // 分页显示定制
    protected $config  = array('prev'=>'上一页','next'=>'下一页','theme'=>'  %prePage%  %linkPage%  %nextPage%  %numberPage% %totalPage%');
    // 默认分页变量名称
    public $varPage;

    //初始化时，计算出当前页数和起始行数
    public function __construct($totalRows,$listRows=20, $cat_id=0, $ticket_id=0, $ajax_func='server') {
        $this->totalRows = $totalRows;  //总记录数
        $this->ajax_func = $ajax_func;  //对应js的ajax功能函数名
        
        //page参数名字获取，如果config文件有定义则取config，没有，则默认为“page” 
        $this->varPage = C('VAR_PAGE') ? C('VAR_PAGE') : 'page' ;
        $this->listRows = intval($listRows);

        //计算总页数，向上取整
        $this->totalPages = ceil($this->totalRows/$this->listRows);     
        //计算分栏数，用于比如每隔5页向前向后跳转
        $this->coolPages  = ceil($this->totalPages/$this->rollPage);

        //如果url中没有var_page参数，则默认为第一页处理
        $this->nowPage  = !empty($_GET[$this->varPage])?intval($_GET[$this->varPage]):1;

        //商品cat_id类
        $this->cat_id  = $cat_id;
        //优惠券ticket_id
        $this->ticket_id = $ticket_id;
        //防呆处理:如果当前页大于总页数，则将总页数值赋值给当前页（常发生于在当前页为最后一页时按“下一页”操作）
        if(!empty($this->totalPages) && ($this->nowPage > $this->totalPages) ){
            $this->nowPage = $this->totalPages;
        }

        //当前页的起始行数，本应该是要加1才是当前页的第一行
        //但考虑该属性是用于limit(n,m)方法的第一个参数，也即跳过n行取m行的意思
        //故这里的实际效果是当前页的上一页尾行的行号
        $this->firstRow = $this->listRows*($this->nowPage-1) ;
    }

    //修改config参数
    public function setConfig($name,$value) {
        if(isset($this->config[$name])) {
            $this->config[$name]    =   $value;
        }
    }

    //根据当前页，计算得到分页相关格式和数据字符串
    public function show() {
        //如果没有数据，返回空
        if($this->totalPages <= 1) return "<input type='hidden' id='cidNumber' value='".$this->cat_id."'><input type='hidden' id='ticketNumber' value='".$this->ticket_id."'>";
        $upRow = $this->nowPage - 1;
        $downRow = $this->nowPage + 1;
        if ($upRow>0){            
            $upPage="<div class='tabulation_page'><div class='tabulation_page_fl'><a href='JavaScript:".$this->ajax_func."(".$this->ticket_id.",".$upRow.",".$this->cat_id.")'>".$this->config['prev']."</a>";
        }else{
            $upRow=1;
            $upPage="<div class='tabulation_page'><div class='tabulation_page_fl'><a href='JavaScript:".$this->ajax_func."(".$this->ticket_id.",".$upRow.",".$this->cat_id.")'>".$this->config['prev']."</a>";
        }

        if ($downRow <= $this->totalPages){
            $downPage="<a href='JavaScript:".$this->ajax_func."(".$this->ticket_id.",".$downRow.",".$this->cat_id.")'>".$this->config['next']."</a></div>";
        }else{
            $downRow = $this->totalPages;
            $downPage="<a href='JavaScript:".$this->ajax_func."(".$this->ticket_id.",".$downRow.",".$this->cat_id.")'>".$this->config['next']."</a></div>";
        }
        
        $nowCoolPage = ceil($this->nowPage/$this->rollPage);
       // 1 2 3 4 5
        $linkPage = "";
        for($i=1;$i<=$this->rollPage;$i++){
            //假设当前页为23，总页数25，分页每页5
            //则当前栏数为5，$page从21开始到25
            $page=($nowCoolPage-1)*$this->rollPage+$i;
            //如果不为当前页
            if($page!=$this->nowPage){
                //$page不超过总页数，该判断是用于防止总页数少于$rollPage的情况
                if($page<=$this->totalPages){
                   $linkPage .= "<a class='item' href='JavaScript:".$this->ajax_func."(".$this->ticket_id.",".$page.",".$this->cat_id.")'>".$page."</a>";
                }else{
                    break;
                }
            }else{
                //如果总页数为1，则不显示任何样式和内容
                if($this->totalPages != 1){
                    $linkPage .= "<a class='item on' href='JavaScript:".$this->ajax_func."(".$this->ticket_id.",".$page.",".$this->cat_id.")'>".$page."</a>";
                }
            }
        }
        $numberPage = "<div class='tabulation_page_fr'><span>第</span><input name='go_page' id='go_page' class='page_text' type='text'><span>页</span><input value='跳转'' class='page_btn' onclick='jump_page();' type='button'></div>";
        $totalPage = "(共".$this->totalPages."页)</div><input type='hidden' id='cidNumber' value='".$this->cat_id."'><input type='hidden' id='ticketNumber' value='".$this->ticket_id."'> ";

        $pageStr  =  str_replace(  
            array('%prePage%','%nextPage%','%linkPage%' ,'%numberPage%','%totalPage%'),
            array($upPage,$downPage,$linkPage,$numberPage,$totalPage),
            $this->config['theme']
        ); 

        return $pageStr;
    }

}

?>