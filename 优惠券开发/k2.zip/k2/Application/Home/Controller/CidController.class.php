<?php
namespace Home\Controller;
use Think\Controller;
class CidController extends CommonController {

	///
	///首页展示
	///
    public function index(){
    	
        $cat_id = isset($_GET['cat_id'])?$_GET['cat_id']:0;
        $ticket_id = isset($_GET['ticket_id'])?$_GET['ticket_id']:0;

        //全部商品
        if($cat_id == 0){
            $Goods = M('total');
            switch ($ticket_id) {
                case 0: //所有优惠
                    $map = '1';                    
                    break;
                case 1: // 100以上的优惠券
                    $map['quan'] =array('gt',100);                    
                    break;
                case 2: //50-100之间的优惠券
                    $map['quan'] =array('between',array('50','100')); 
                    break;
                case 3:
                    $map['quan'] =array('between',array('30','49.9')); 
                    break;
                case 4:
                    $map['quan'] =array('between',array('10','29.9')); 
                    break;
                case 5:
                    $map['quan'] =array('lt',10);                    
                    break;
            }

            $count = $Goods->where($map)->count();
            $Page   = new \Home\Common\TotalAjaxPage($count,40,$cat_id,$ticket_id,"getticket");
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select(); 

        } else {
            //根据cat_id确定商品类型
            $Goods =M('api');
            $map2['cid'] = $cat_id; 
            switch ($ticket_id) {
                case 0: //所有优惠
                    $map = '1';                    
                    break;
                case 1: // 100以上的优惠券
                    $map['quan'] =array('gt',100);                    
                    break;
                case 2: //50-100之间的优惠券
                    $map['quan'] =array('between',array('50','100')); 
                    break;
                case 3:
                    $map['quan'] =array('between',array('30','49.9')); 
                    break;
                case 4:
                    $map['quan'] =array('between',array('10','29.9')); 
                    break;
                case 5:
                    $map['quan'] =array('lt',10);                    
                    break;
            } 
            $count  = $Goods->where($map2)->where($map)->count();
            $Page   = new \Home\Common\TotalAjaxPage($count,40,$cat_id,$ticket_id,"getticket");         
            $datas = $Goods->where($map2)->where($map)->limit($Page->firstRow,$Page->listRows)->select();
            
        }
        
        $show   = $Page->show();// 分页显示输出
        $this->assign('cid',$cat_id);
        $this->assign('datas',$datas);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出 
        $this->show();
    }

    public function ajaxGet02(){

		$pageSize = 40;
		$cat_id = isset($_GET['cat_id'])?$_GET['cat_id']:0;
        $ticket_id = isset($_GET['ticket_id'])?$_GET['ticket_id']:0;
        
        if($cat_id == 0){
            $Goods = M('total');
            switch ($ticket_id) {
                case 0:
                    $map = '1';                    
                    break;
                case 1:
                    $map['quan'] =array('gt',100);                    
                    break;
                case 2:
                    $map['quan'] =array('between',array('50','100')); 
                    break;
                case 3:
                    $map['quan'] =array('between',array('30','50')); 
                    break;
                case 4:
                    $map['quan'] =array('between',array('10','30')); 
                    break;
                case 5:
                    $map['quan'] =array('lt',10);                    
                    break;
            }

            $count = $Goods->where($map)->count();
            $Page   = new \Home\Common\TotalAjaxPage($count,40,$cat_id,$ticket_id,"getticket");
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select(); 

        } else {
            $Goods =M('api');
            $map2['cid'] = $cat_id; 
            switch ($ticket_id) {
                case 0:
                    $map = '1';                    
                    break;
                case 1:
                    $map['quan'] =array('gt',100);                    
                    break;
                case 2:
                    $map['quan'] =array('between',array('50','100')); 
                    break;
                case 3:
                    $map['quan'] =array('between',array('30','50')); 
                    break;
                case 4:
                    $map['quan'] =array('between',array('10','30')); 
                    break;
                case 5:
                    $map['quan'] =array('lt',10);                    
                    break;
            } 
            $count  = $Goods->where($map2)->where($map)->count();
            $Page   = new \Home\Common\TotalAjaxPage($count,40,$cat_id,$ticket_id,"getticket");         
            $datas = $Goods->where($map2)->where($map)->limit($Page->firstRow,$Page->listRows)->select();
            
        }
        
        $show   = $Page->show();// 分页显示输出
        $this->assign('cid',$cat_id);
        $this->assign('datas',$datas);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出 

        $res = $this-> fetch();
        $this->ajaxReturn($res);
    }
   	
    //点击搜索框对应的结果	
    public function search(){
        $pid="mm_113516953_36040316_132152895";
        $keywords = I('post.keywords');
        $page = 1;
        $ticket = 0;
        $Goods = new \Common\Common\ApiData();
        $modelTemp = M('temp');
        if($modelTemp->count()){
            $modelTemp->where("1")->delete();  
        }

        //获取搜索结果的json数据
        for($j=1;$j<=50;$j++){

            $url = "http://api.yishoudan.com/index/index?kiss=".$keywords."&pname=page&aname=page&p=".$j."&json=1";
            $arrs = $Goods -> getDatas($url);
            if(empty($arrs)){
                break;
            }
                    
            $this->addPid($arrs,$pid);
            $modelTemp->addAll($arrs);
        }                  

        $count = $modelTemp->count();
        $Page   = new \Home\Common\SearchAjaxPage($count,40,$page,$ticket,"searchKW");
        $datas = $modelTemp->limit($Page->firstRow,$Page->listRows)->select(); 

        $show   = $Page->show();// 分页显示输出
        $this->assign('count',$count);
        $this->assign('keyword',$keywords);
        $this->assign('datas',$datas);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出 
        $this->display();
    }

    public function ajaxGet03(){

        $pageSize = 40;
        $ticket_id = !empty(I('get.ticket_id'))?I('get.ticket_id'):0;
        $page = I('get.page');
        $keywords = I('get.keywords');
        
        $Goods = M('temp');  
        switch ($ticket_id) {
            case 0: //所有优惠
                    $map = '1';                    
                    break;
                case 1: // 100以上
                    $map['coupon_quan_price'] =array('gt',100);                    
                    break;
                case 2: //50-100之间
                    $map['coupon_quan_price'] =array('between',array('50','100')); 
                    break;
                case 3:
                    $map['coupon_quan_price'] =array('between',array('30','49.9')); 
                    break;
                case 4:
                    $map['coupon_quan_price'] =array('between',array('10','29.9')); 
                    break;
                case 5:
                    $map['coupon_quan_price'] =array('lt',10);                    
                    break; 
        } 

        $count  = $Goods->where($map)->count();
        $Page   = new \Home\Common\SearchAjaxPage($count,40,$page,$ticket_id,"searchKW");         
        $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();

        $show   = $Page->show();// 分页显示输出
        $this->assign('count',$count);
        $this->assign('keyword',$keywords);
        $this->assign('datas',$datas);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出 

        $res = $this-> fetch();
        $this->ajaxReturn($res);
    }

    public function addPid(&$datas,$pid){
        if(empty($datas)){
            return;
        }

        for ($i=0;$i<count($datas);$i++) {
            $datas[$i]['cid'] = intval($datas[$i]['cid']);
            $datas[$i]['diadurl'].= $pid;
        }

        $this->checkData($datas);
    }

    public function checkData(&$datas){
        if(empty($datas)){
            return;
        }

        for ($i=0;$i<count($datas);$i++) {
            if( $datas[$i]['cid'] >=15){
                unset($datas[$i]);
            }
        }
    }
}