<?php
namespace Home\Controller;
use Think\Controller;
class TaoqgController extends CommonController {
    
    public function index(){
        $ticket_id = !empty(I('get.ticket'))?I('get.ticket'):0;
    	$page = !empty(I('get.page'))?I('get.page'):1;
        $Goods = M('taoqg');

        switch ($ticket_id) {
            case 0: //所有优惠
                    $map = '1';                    
                    break;
                case 1: // 100以上
                    $map['coupon_quan_price'] =array('gt',100);                    
                    break;
                case 2: //50-100之间
                    $map['coupon_quan_price'] =array('between',array('50','100')); 
                    break;
                case 3:
                    $map['coupon_quan_price'] =array('between',array('30','49.9')); 
                    break;
                case 4:
                    $map['coupon_quan_price'] =array('between',array('10','29.9')); 
                    break;
                case 5:
                    $map['coupon_quan_price'] =array('lt',10);                    
                    break;         
        }

        $count = $Goods->where()->where($map)->count();
        $Page   = new \Home\Common\OthersPage($count,40,$ticket_id);
        $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();
        
        $show   = $Page->show();// 分页显示输出
        $this->assign('datas',$datas);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出
        $this->display();
    }

    
    
}