<?php
namespace Home\Controller;
use Think\Controller;

class CommonController extends Controller {
    
    public function __construct(){
        //初始化时先执行Controller的初始化方法，
        //防止thinkphp提供的相关控制器方法使用不了
        parent::__construct();
        $this->header();
        $this->indexheader();
    }

    public function header(){
        $ControllerName = CONTROLLER_NAME;

        $lanmu = M('lanmu');
        $flags = $lanmu->order("id")->select();
        $this->assign('flags', $flags);
        $this->assign('name', $ControllerName);
        
    }

    public function indexheader(){
        $ControllerName = CONTROLLER_NAME;

        $lanmu = M('lanmu');
        $flags = $lanmu->order("id")->select();
        $this->assign('flags', $flags);
        $this->assign('name', $ControllerName);
        
    }

    
    
}