<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends CommonController {

	///
	///首页展示
	///
    public function index(){
    	$Goods = M('total');
        $datas = $Goods->limit(0,40)->select();
        $this->assign("datas",$datas);
        $this->display();
    }

    public function ajaxGet(){		
		$pageSize = 40;
		$cat_id = isset($_GET['cat_id'])?$_GET['cat_id']:0;
		switch ($cat_id) {
			case 0:
                $Goods=M('total');
                $nums = $Goods->count();
				break;			
			case 1:
				$Goods=M('api');
                $nums = $Goods->where("cid=1")->count();
				break;
            case 2:
                $Goods=M('api');
                $nums = $Goods->where("cid=2")->count();
                break;
            case 3:
                $Goods=M('api');
                $nums = $Goods->where("cid=3")->count();
                break;
            case 4:
                $Goods=M('api');
                $nums = $Goods->where("cid=4")->count();
                break;
            case 5:
                $Goods=M('api');
                $nums = $Goods->where("cid=5")->count();
                break;
            case 7:
                $Goods=M('api');
                $nums = $Goods->where("cid=7")->count();
                break;
            case 8:
                $Goods=M('api');
                $nums = $Goods->where("cid=8")->count();
                break;
            case 9:
                $Goods=M('api');
                $nums = $Goods->where("cid=9")->count();
                break;
            case 10:
                $Goods=M('api');
                $nums = $Goods->where("cid=10")->count();
                break;
            case 11:
                $Goods=M('api');
                $nums = $Goods->where("cid=11")->count();
                break;
            case 12:
                $Goods=M('api');
                $nums = $Goods->where("cid=12")->count();
                break;
            case 13:
                $Goods=M('api');
                $nums = $Goods->where("cid=13")->count();
                break;
            case 14:
                $Goods=M('api');
                $nums = $Goods->where("cid=14")->count();
                break;
            case 30:
                $Goods=M('today');
                $nums = $Goods->count();
                break;
            case 40:
                $Goods=M('top100');
                $nums = $Goods->count();
                break;
            case 50:
                $Goods=M('pingpai');
                $nums = $Goods->count();
                break;
            case 60:
                $Goods=M('jingpai');
                $nums = $Goods->count();
                break;
            case 70:
                $Goods=M('total');
                $map['coupon_quan_price'] =array('elt',9.9);
                $nums=$Goods->where($map)->count();                
                break;
            case 80:
                $Goods=M('total');
                $map['coupon_quan_price'] =array('between',array(10,29.9));
                $nums=$Goods->where($map)->count();
                break;
            case 90:
                $Goods=M('total');
                $map['coupon_quan_price'] =array('between',array(30,49.9));
                $nums=$Goods->where($map)->count();
                break;
            case 100:
                $Goods=M('total');
                $map['coupon_quan_price'] =array('between',array(50,99.9));
                $nums=$Goods->where($map)->count();
                break;
		}   

        $Page  = new \Home\Common\AjaxPage($nums,$pageSize,$cat_id,"server"); 
        $datas = null;

        if($cat_id>=1 and $cat_id<=14){
            $map["cid"] = $cat_id;
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==0 or $cat_id==30) {
            $datas = $Goods ->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==40){
            $datas = $Goods->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==50){
            $datas = $Goods->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==60){
            $datas = $Goods->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==70){
            $map['coupon_quan_price'] =array('elt',9.9);
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==80){
            $map['coupon_quan_price'] =array('between',array(10,29.9));
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==90){
            $map['coupon_quan_price'] =array('between',array(30,49.9));
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();
        } elseif($cat_id==100){
            $map['coupon_quan_price'] =array('between',array(50,99.9));
            $datas = $Goods->where($map)->limit($Page->firstRow,$Page->listRows)->select();
        }
        
        $show   = $Page->show();// 分页显示输出
        $this->assign('datas',$datas);// 赋值数据集
        $this->assign('page',$show);// 赋值分页输出 
        $res = $this-> fetch();
        $this->ajaxReturn($res);
    }
   		
    
}