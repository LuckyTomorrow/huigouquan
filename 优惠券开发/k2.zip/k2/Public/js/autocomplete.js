/**
A jQuery plugin for search hints

Author: Lorenzo Cioni - https://github.com/lorecioni
*/
function displaydo(id){
 obj = document.getElementById(id);
 obj.style.display = obj.style.display == "block"? "none" : "block";
}

(function($) {
		$(document).bind("click",function(e){ 
			//$('.proposal-list').empty();
			var target = $(e.target); 
			if(target.closest(".text").length == 0){ 
				$(".search_in").hide(); 
				$(".re_search_box").hide(); 
			} 
		});
		$(window).scroll(function(){
			var top = $(window).scrollTop();
			if(top >= 1000){
				$(".muew_fix").css("display","block");
			}else{
				$(".muew_fix").css("display","none");
			}
		  });
		var word_top  = '鐗逛环杩欓噷鏈夛紝杈撳叆鍏抽敭璇嶆悳绱紒';
		var $word_top = $('.search_box .text');
	   
		
		//$word_top.focusClear();
	   
		if(!$word_top.val()){
			$word_top.val(word_top);
		}
		
		$word_top.focus(function(){
			// $('.search_in').show();
			if( $(this).val()==word_top){
				
				$(this).val('');
			}
		}).blur(function(){
			// $('.search_in').hide();
			if( !$(this).val()){
				
				$(this).val(word_top);
			}
		});
		function chzjwl(){
							$.ajax({
								url:"{:U('search/search_list')}",
						        type:"POST",
						        data:"",
						        dataType:"json",
						        timeout:4000,
						        success:function(data){
						        	console.log(data);
						        }
							});
				}
	$.fn.autocomplete = function(params) {
		
		//Selections
		var currentSelection = -1;
		var currentProposals = [];
		
		//Default parameters
		params = $.extend({
			hints: [],
			placeholder: '',
			width: 200,
			height: 16,
			showButton: true,
			buttonText: 'Search',
			onSubmit: function(text){},
			onBlur: function(){}
		}, params);

		//Build messagess
		this.each(function() {
			//Container
			var searchContainer = $('<div></div>')
				.addClass('autocomplete-container')
				// .css('height', params.height * 2);	
				
			//Text input		<input name="keyword" id="keywords" value="" class="text" onclick='displaydo("search_in");'/>
			var input = $('<input type="text" autocomplete="off" name="keyword" id="keywords" value="鐗逛环杩欓噷鏈夛紝杈撳叆鍏抽敭璇嶆悳绱紒" class="h_serch">')
				.attr('placeholder', params.placeholder)
				.addClass('autocomplete-input')
				// .css({
				// 	'width' : params.width,
				// 	'height' : params.height
				// });
			
			// if(params.showButton){
			// 	input.css('border-radius', '3px 0 0 3px');
			// }

			//Proposals
			var proposals = $('<div></div>')
				.addClass('proposal-box')
				.css({
					'z-index':99,
					'background':'#ffff'
				})
				.css('width', params.width + 65)
				.css('top', input.height() + 33);

			var proposalList = $('<ul></ul>')
				.addClass('proposal-list');

			proposals.append(proposalList);
			
			input.keydown(function(e) {
				switch(e.which) {
					case 38: // Up arrow
					e.preventDefault();
					$('ul.proposal-list li a').removeClass('selected');
					if((currentSelection - 1) >= 0){
						currentSelection--;
						$( "ul.proposal-list li a:eq(" + currentSelection + ")" )
							.addClass('selected');
					} else {
						currentSelection = -1;
					}
					break;
					case 40: // Down arrow
					e.preventDefault();
					if((currentSelection + 1) < currentProposals.length){
						$('ul.proposal-list li a').removeClass('selected');
						currentSelection++;
						$( "ul.proposal-list li a:eq(" + currentSelection + ")" )
							.addClass('selected');
					}
					break;
					case 13: // Enter
						if(currentSelection > -1){
							var text = $( "ul.proposal-list li a:eq(" + currentSelection + ")" ).html();
							input.val(text);
						}
						currentSelection = -1;
						proposalList.empty();
						params.onSubmit(input.val());
						break;
					case 27: // Esc button
						currentSelection = -1;
						proposalList.empty();
						input.val('');
						break;
				}
			});
				
			input.bind("keyup keydown", function(e){
				if(e.which != 13 && e.which != 27 
						&& e.which != 38 && e.which != 40){				
					currentProposals = [];
					currentSelection = -1;
					proposalList.empty();
					if(input.val() != ''){
						// console.log(input.val());
						var word = "^" + input.val() + ".*";
						$.ajax({
								url:"http://www.youpingou.com/search/search_list",
						        type:"POST",
						        data:{key:input.val()},
						        dataType:"json",
						        jsonp:"callback",
						        success:function(data){	
						        	if (data.status==1) {
						        		proposalList.empty();
										for(var test in data.msg){
											// if(data.msg[test].match(word)){
												currentProposals.push(data.msg[test]);	
												var herf="http://www.youpingou.com/search/re_search/keyword/"+data.msg[test];
												var element1 = $('<li></li>').append('<a></a>')
												var element2 = $('<li></li>')
												element2.addClass('proposal')
												var element =$('<a href='+herf+' target="_blank"></a>')
													.html(data.msg[test])
													.click(function(){
														input.val($(this).html());
														// proposalList.empty();
														// params.onSubmit(input.val());
													})
													.mouseenter(function() {
														$(this).addClass('selected');
													})
													.mouseleave(function() {
														$(this).removeClass('selected');
													});

												proposalList.append(element2);
												element2.append(element);



											// }
										}
						        	}
						        	
						        }
							});
						
					}
				}
			});
			
			// input.blur(function(e){
			// 	currentSelection = -1;
			// 	proposalList.empty();
			// 	// params.onBlur();
			// });
			
			searchContainer.append(input);
			searchContainer.append(proposals);		
			
			if(params.showButton){
				//Search button
				var button = $('<div></div>')
					// .addClass('autocomplete-button')
					// .html(params.buttonText)
					// .css({
					// 	'height': params.height + 2,
					// 	'line-height': params.height + 2 + 'px'
					// })
					.click(function(){
						proposalList.empty();
						params.onSubmit(input.val());
					});
				searchContainer.append(button);	
			}
	
			$(this).append(searchContainer);	
			
			// if(params.showButton){
			// 	//Width fix
			// 	searchContainer.css('width', params.width + button.width() + 50);
			// }
		});

		return this;
	};

})(jQuery);



