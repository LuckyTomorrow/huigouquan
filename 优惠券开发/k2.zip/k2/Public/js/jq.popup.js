/*
* jQuery clstip plugin
* Version 1.0 (03/23/2015)
* @requires jQuery v1.2.6 or later
*
*/
$(function(){
	$(".ClsCollectTip").clstip();
	//$("#list li.box a").collection();
	$(".ForClsCollectTip").clstip({"clstype":1});
	$.Autotipsinput(
		["searchBoxInput"],
		["搜索关键字…"]
	).init();
	$.InviteReceiveBtn(
		["claimBrowse","claimReg","claimSign","claimCompleteuser"]
	).init();
});

(function($){
	$.fn.clstip = function(options){
		var opts = $.extend({}, $.fn.clstip.defaults, options);
		return this.each(function() {
			if($.cookie("collectTip")){
				$(this).parents(".tip").hide();
			}else{
				$(this).parents(".tip").show();
			}
			$(this).unbind("click").bind("click", function(){
				if(opts.clstype){
					$.cookie("collectTip", "true", {expires: 7, path: "/", domain: "5395.com"});
				}else{
					$.cookie("collectTip", "true", {path: "/", domain: "5395.com"});
				}
				$(this).parents(".tip").slideUp(300);
			});
		});
	};
	$.fn.clstip.defaults = {
        clstype: 0 //0默认关闭浏览器后打开还是能显示1是永久关闭
    };
})(jQuery);
(function($){
	$.fn.collection = function(options){
		var opts = $.extend({}, $.fn.option, options);
		return this.each(function() {
			var _curobj = $(this), goodsid=_curobj.attr("data-gid");
			_curobj.hover(function(e){
				datasc=_curobj.attr("data-sc");
				$(".fav_h").remove();
				$(".fav").remove();
				_curobj.prepend((opts.showHtml).replace(/{{&gid}}/g, goodsid));
				if(datasc==1) {
					$(".fav_h").addClass("fav").removeClass('fav_h').attr('title', '取消收藏');
				}
			},
			function(){
				$(".fav_h").remove();
				//$(".fav").show();
				$(".fav").remove();
			});

			/*
			//收藏商品
			$(document).delegate('.fav_h', 'click', function() {
				var $this = $(this);
				var gid = $this.attr('data-id');
				$.ajax({
					url: '?m=ajax&ac=operate&op=favorite',
					type: 'POST',
					dataType: 'json',
					data: {
						gid: gid
					},
					success: function(result) {
						if (result.code == -2) {
							log_pop('log');
						} else if (result.code == 0) {
							$this.removeClass('fav_h').addClass('fav');
							$this.attr('title', '点击取消收藏');
							message_tip(result.msg);
						} else {
							message_tip(result.msg, 3000);
						}
					}
				});
			});
			//取消收藏商品
			$(document).delegate('.fav', 'click', function() {
				var $this = $(this);
				var gid = $this.attr('data-id');
				$.ajax({
					url: '?m=ajax&ac=operate&op=delfavorite',
					type: 'POST',
					dataType: 'json',
					data: {
						gid: gid
					},
					success: function(result) {
						if (result.code == -2) {
							log_pop('log');
						} else if (result.code == 0) {
							$this.removeClass('fav').addClass('fav_h');
							$this.attr('title', '点击收藏');
							message_tip(result.msg);
						} else {
							message_tip(result.msg, 3000);
						}
					}
				});
			});
			*/
		});
	};
	$.fn.option = {
		showHtml: '<a class="fav_h"   title="点击收藏"   href="javascript:void(0);"   id="cang"   data-id="{{&gid}}"></a>'
	};
})(jQuery);

/*
$("div").delegate("p","click",function(){
	$(this).slideToggle();
});
$("button").click(function(){
	$("<p>这是一个新段落。</p>").insertAfter("button");
});
*/

$.Autotipsinput = function (m,n) {
	$.Autotipsinput.inputTops = {
		input:m,
		text:n,
		defaultColor:{focus:'#000', blur:'#9C9A9C'}
	};
	subAutoTip = {
		init:function(e){
			$.each($.Autotipsinput.inputTops.input, function(a,b){
				$.Autotipsinput.jqi = $("."+$.Autotipsinput.inputTops["input"][a]);
				$.Autotipsinput.jqi.css("color",$.Autotipsinput.inputTops.defaultColor.blur);
				$.Autotipsinput.jqi.unbind("focus").focus(function(e){
					if ( this.value == $.Autotipsinput.inputTops["text"][a] ) {
						this.value = '';
						this.style.color = $.Autotipsinput.inputTops.defaultColor.focus;
					}
				}).
				blur(function(e){
					if (!this.value) {
						this.value = $.Autotipsinput.inputTops["text"][a];
						this.style.color = $.Autotipsinput.inputTops.defaultColor.blur;
					}
				});
			});
		}
	};
	return subAutoTip;
}


/*$.InviteReceiveBtn(
		["claimBrowse","claimReg","claimSign","claimCompleteuser"]
	).init();
*/
$.InviteReceiveBtn = function (m,n) {
	$.InviteReceiveBtn.defaultval = {
		btn:m,
		dialogHtml:'<div class="popup" id="InviteReceiveBtnpopup2"><h2><span>领取</span><a href="JavaScript:popup_close();" title="关闭"></a></h2><div class="popup_tick"><img src="/static/popup/tick.png"/><div class="popup_tick_right">领取成功! 恭喜您获得金币+{{&jinbi}}</div></div><div class="popup_botton_close"><a href="JavaScript:popup_close();">确定</a></div></div>'
	};
	return {
		init:function(e){
			$.each($.InviteReceiveBtn.defaultval.btn, function(a,b){
				var popup_height = 0,popup_width = 0,window_popup_height = 0,window_popup_width = 0,o = '';
				$.InviteReceiveBtn.jqi = $("#"+$.InviteReceiveBtn.defaultval["btn"][a]);
				$.InviteReceiveBtn.jqi.unbind("click").click(function(e){
					$.ajax({
						url: '/invite/?action='+$.InviteReceiveBtn.defaultval["btn"][a],
						type: 'POST',
						dataType: 'json',
						data: {
							r: new Date().getTime()
						},
						success: function(result) {
						
							if (result.error == -2) {
								//log_pop('log');
							} else if (result.error == 0) {
								o = $.InviteReceiveBtn.defaultval.dialogHtml;
								o = o.replace(/{{&jinbi}}/, result.prizecoins);
								$("body").append(o);
								popup_width = 232/2;
								window_popup_width = document.body.clientWidth/2;
								popleft = window_popup_width-popup_width;
								$('#InviteReceiveBtnpopup2').css({'top':163, 'left':popleft}).show();
							} else {
								
							}
						}
					});
				});
			});
		}
	};
}
function popup_close(){
	$('#InviteReceiveBtnpopup2').remove();
	window.location.reload();
}