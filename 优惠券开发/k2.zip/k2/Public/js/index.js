$(function(){
	slideNav('#slideNav li','#slideImg li');
	slideAutoPlay('#slideNav li');
})
var slideTimer;
var slideSpeed = 5000;

function slideNav(_source,_target){
	$(_target+':first').css('z-index',1);
	slideNum = $(_target).size();
	for(i=1;i<slideNum;i++){
		$(_source).parent().append('<li></li>');
	}
	$(_source).mouseenter(function(){
		if(!$(this).hasClass('on')){
			$(_source).removeClass();
			$(this).addClass('on');
			slideNavindex = $(this).index();
			$(_target).hide();
			$(_target).eq(slideNavindex).fadeIn();
		}
	})
	$(_source).add(_target).mouseenter(function(){
		clearInterval(slideTimer);
	}).mouseleave(function(){
		slideAutoPlay('#slideNav li');
	})
}
function slideAutoPlay(_source){
	slideTimer = setInterval(function(){
		li_first = $(_source+':first');
		li_now   = $(_source+'[class="on"]');
		li_next  = li_now.next();
		if(li_next[0]){
			li_next.mouseenter();
		}else{
			li_first.mouseenter();
		}
	},slideSpeed);
}
function  qiandao(){
	$("#lightpopup").show();
	$("#exposeMask").show();
	$("#DD").show();
	$("#ZC").hide();
	$(".pop_title").html("您尚未登录");
	$("#DDDDD").addClass("z_tab_current");
	$("#ZCZ").removeClass("z_tab_current");
	$(".poplogin_switch").html("");
	
}
//收藏
$(document).delegate('.fav_h', 'click', function() {
		var $this = $(this);
		var gid = $this.attr('data-id');
		$.ajax({
			url:"/article/shouye.php",
			type:"get",
			data:{'id':gid},
			dataType: 'json',
			success:function(data){
				if(data.msg=='1'){
					$this.removeClass('fav_h').addClass('fav');
					$this.parent().attr('data-sc', 1);
					$this.attr("title","已收藏");
					//alert(cang.adang);
					//alert("收藏成功");
				}else if(data.msg=='0'){
					alert("收藏失败，请重新收藏");
				}else  if(data.msg=='2'){
					$this.removeClass('fav_h').addClass('fav');
					$this.parent().attr('data-sc', 1);
					$this.attr("title","已收藏");
					//alert("已收藏");
				}else  if(data.msg=='7'){
					//$this.removeClass('fav_h').addClass('fav_h');
					//$this.parent().attr('data-sc', 1);
					//$this.attr("title","已收藏");
					//alert("已收藏");
					//alert("请先登录");
					$("#lightpopup").show();
					$("#exposeMask").show();
					$("#DD").show();
					$("#ZC").hide();
					$(".pop_title").html("您尚未登录");
					$("#DDDDD").addClass("z_tab_current");
					$("#ZCZ").removeClass("z_tab_current");
					$(".poplogin_switch").html("");
					
				}
			}
		})

});

//取消收藏
$(document).delegate('.fav', 'click', function() {
		var $this = $(this);
		var gid = $this.attr('data-id');
		//alert(gid);return;s
		$.ajax({
			url:"/article/shouyechu.php",
			type:"get",
			data:{'id':gid},
			dataType: 'json',
			success:function(data){
				//alert(data.msg);
				if(data.msg=='6'){
					$this.removeClass('fav').addClass('fav_h');
					$this.parent().attr('data-sc', 0);
					$this.attr("title","点击收藏");
					//alert("取消收藏");
					
				}else if(data.msg=='5'){
					//alert(data.msg);
					alert("取消收藏失败，请重新收藏");
				}
			}
		})

});

$(function(){
	$('.sign').click(function(){
		$('#show_top_menu').toggle();
	})
	$('#show_top_menu .menu_content .up_menu').click(function(){
		$('#show_top_menu').hide();
	})
	$('.tuwen_tkl .pic_detail span.pic_detail_btn_span').click(function(){
		$('.pic_detail_show').toggle();
	})
	
	
	$('.buy_wrapper .buy_2he1').click(function(){
		$('.hint_information').show();
	})
	$('.hint_information').click(function(){
		$('.hint_information').hide();
	})
})

$(function() {
	$('.app_android').mouseenter(function() {
		$('.appcode').show();
	})
	$('.app_android').mouseleave(function() {
		$('.appcode').hide();
	})
})

$(function(){
	window.onscroll = function(){
		var s = document.documentElement.scrollTop || document.body.scrollTop;  
		if( s >= 760 ) { 
			$('.index_category').addClass('index_category_1'); 
		} else { 
			$('.index_category').removeClass('index_category_1'); 
		}
	}
})

