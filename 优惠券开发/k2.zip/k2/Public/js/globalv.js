$(function(){
  jQuery('.wsgwTitle .lou span').each(function(index, element){jQuery(element).html((index+1)+'F');});
  jQuery('.HomeList .first').each(function(index, element){jQuery(element).addClass('f'+(index+1));});
  jQuery('.mod_menu ul li i').each(function(index, element){jQuery(element).addClass('ico'+(index+1));});
  jQuery('.minBox .minPic').hover(
	function(){
	  jQuery(".minBox .minPic").stop().animate({
	    opacity: '1'
	  },500);
	  jQuery(this).stop().animate({
	    opacity: '0.8'
	  },500);
	},
	function(){
	  jQuery('.minBox .minPic').stop().animate({
	    opacity: '1'
	  },500);
	}
  );
  jQuery('.mod_menu ul li').hover(
	function(){
	  jQuery(this).addClass('hover');
	},
	function(){
	  jQuery(this).removeClass('hover');
	}
  );
  jQuery('.HomeList ul li.Feedback').hover(
	function(){
	  jQuery(this).addClass('hover');
	},
	function(){
	  jQuery(this).removeClass('hover');
	}
  );
  
  jQuery('.J_SearchTab').hover(
	function(){
	  jQuery(this).addClass('hover');
	},
	function(){
	  jQuery(this).removeClass('hover');
	}
  );
  jQuery('.mod_cateH').hover(
	function(){
	  jQuery(this).addClass('hover');
	},
	function(){
	  jQuery(this).removeClass('hover');
	}
  );

	$(window).scroll( function(){
	  var scrollheight=jQuery(window).scrollTop();
	  var TopHeight = jQuery('.top').outerHeight()+jQuery('.header').outerHeight();
	  if(scrollheight>TopHeight){
		jQuery('.headerNav').addClass('scrollNav');
		jQuery('.scrollNav .mod_cate').hover(
		  function(){
			jQuery(this).addClass('hover');
		  },function(){
			jQuery(this).removeClass('hover');
		  }
		);
	  }else{
		jQuery('.headerNav').removeClass('scrollNav');
	  }
	});
$("b#topnosignin").unbind("click").click(function(n){
		$.ajax({
			type:'post',
			url: '/u/home.php',data:{m:'ajaxDosignin',ajax:1},
			success:function(data){
				var datas = eval("("+data+")");
				$("#topnosignin").html('已签到').addClass('yes'),$("b.yes").unbind("click");
				popwindow('siginpop', datas.content, 2000),n.stopPropagation();
			}
		});
	});
  jQuery(".slide").slide( {mainCell:".bd ul",autoPlay:true,interTime:8000,autoPage:true,titCell:".hd ul",delayTime:1200});
  $("img.wsgw-lazy").lazyload({ 
    effect : "fadeIn"
  });
  (new GoTop()).init({
		pageWidth		:980,
		nodeId			:'go-top',
		nodeWidth		:50,
		distanceToBottom	:125,
		distanceToPage:50,
		hideRegionHeight	:130,
		text	: ''
	});
});

function search_func(search_type){
    var search_type;
    if (search_type=='benzhan'){var type_name1='淘宝';type_name='本站';}else {type_name1='本站';type_name='淘宝';}
    var str='<a href="javascript:;" onclick="search_func('+search_type+')">'+type_name1+'</a>';
	//var s=document.getElementById('stype').innerHTML;alert(s);
	//alert(str);
	if (search_type=='benzhan'){
		document.myform.action="/item/search_index.php"
		document.getElementById('stype').innerHTML=""+type_name+"";
		//document.getElementById('benzhan').innerHTML="";
		document.getElementById('benzhan').innerHTML=str;
	}else {
	    document.myform.action="http://s8.taobao.com/search"
		document.getElementById('stype').innerHTML=""+type_name+"";
		//document.getElementById('benzhan').innerHTML="";
		document.getElementById('benzhan').innerHTML=str;
	}
}

function popwindow(w, s, t) {
	var msgWinObj = document.getElementById(w);
	if(!msgWinObj) {
		var msgWinObj = document.createElement("div");
		msgWinObj.id = w;
		msgWinObj.style.display = 'none';
		msgWinObj.style.position = 'absolute';
		msgWinObj.style.zIndex = '100000';
		msgWinObj.className = 'popuplayer';
		document.body.appendChild(msgWinObj);
	}
	msgWinObj.innerHTML = s;
	msgWinObj.style.display = '';
	msgWinObj.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=0)';
	msgWinObj.style.opacity = 0;
	var sTop = document.documentElement && document.documentElement.scrollTop ? document.documentElement.scrollTop : document.body.scrollTop;
	
	
	pbegin = sTop + (document.documentElement.clientHeight / 2)-60;
	pend = sTop + (document.documentElement.clientHeight / 5)-60;
	setTimeout(function () {showmsgwin(w, pbegin, pend, 0, t)}, 10);
	msgWinObj.style.left = ((document.documentElement.clientWidth - msgWinObj.clientWidth) / 2) + 'px';
	msgWinObj.style.top = pbegin + 'px';
}

function showmsgwin(w, b, e, a, t) {
	step = (b - e) / 10;
	var msgWinObj = document.getElementById(w);
	newp = (parseInt(msgWinObj.style.top) - step);
	if(newp > e) {
		msgWinObj.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=' + a + ')';
		msgWinObj.style.opacity = a / 100;
		msgWinObj.style.top = newp + 'px';
		setTimeout(function () {showmsgwin(w, b, e, a += 10, t)}, 10);
	} else {
		msgWinObj.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=100)';
		msgWinObj.style.opacity = 1;
		setTimeout('displayOpacity(\''+w+'\', 100)', t);
	}
}

function displayOpacity(id, n) {
	if(!document.getElementById(id)) {
		return;
	}
	if(n >= 0) {
		n -= 10;
		document.getElementById(id).style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=' + n + ')';
		document.getElementById(id).style.opacity = n / 100;
		setTimeout('displayOpacity(\'' + id + '\',' + n + ')', 50);
	} else {
		document.getElementById(id).style.display = 'none';
		document.getElementById(id).style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=100)';
		document.getElementById(id).style.opacity = 1;
	}
}